package androidx.window.layout;

import androidx.window.core.SpecificationComputer$VerificationMode;
import androidx.window.sidecar.SidecarDeviceState;
import androidx.window.sidecar.SidecarDisplayFeature;
import androidx.window.sidecar.SidecarWindowLayoutInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class o000oOoO {

    /* JADX INFO: renamed from: OooO00o, reason: collision with root package name */
    public final SpecificationComputer$VerificationMode f5392OooO00o;

    public o000oOoO() {
        SpecificationComputer$VerificationMode specificationComputer$VerificationMode = SpecificationComputer$VerificationMode.QUIET;
        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(specificationComputer$VerificationMode, "verificationMode");
        this.f5392OooO00o = specificationComputer$VerificationMode;
    }

    public static boolean OooO00o(SidecarDeviceState sidecarDeviceState, SidecarDeviceState sidecarDeviceState2) {
        if (com.github.doyaaaaaken.kotlincsv.client.OooO.OooO0Oo(sidecarDeviceState, sidecarDeviceState2)) {
            return true;
        }
        return (sidecarDeviceState == null || sidecarDeviceState2 == null || Oooo0.OooO0O0(sidecarDeviceState) != Oooo0.OooO0O0(sidecarDeviceState2)) ? false : true;
    }

    public static boolean OooO0O0(SidecarDisplayFeature sidecarDisplayFeature, SidecarDisplayFeature sidecarDisplayFeature2) {
        if (com.github.doyaaaaaken.kotlincsv.client.OooO.OooO0Oo(sidecarDisplayFeature, sidecarDisplayFeature2)) {
            return true;
        }
        if (sidecarDisplayFeature == null || sidecarDisplayFeature2 == null || sidecarDisplayFeature.getType() != sidecarDisplayFeature2.getType()) {
            return false;
        }
        return com.github.doyaaaaaken.kotlincsv.client.OooO.OooO0Oo(sidecarDisplayFeature.getRect(), sidecarDisplayFeature2.getRect());
    }

    public static boolean OooO0OO(List list, List list2) {
        if (list == list2) {
            return true;
        }
        if (list == null || list2 == null || list.size() != list2.size()) {
            return false;
        }
        int size = list.size();
        int i = 0;
        while (i < size) {
            int i2 = i + 1;
            if (!OooO0O0((SidecarDisplayFeature) list.get(i), (SidecarDisplayFeature) list2.get(i))) {
                return false;
            }
            i = i2;
        }
        return true;
    }

    public static boolean OooO0Oo(SidecarWindowLayoutInfo sidecarWindowLayoutInfo, SidecarWindowLayoutInfo sidecarWindowLayoutInfo2) {
        if (com.github.doyaaaaaken.kotlincsv.client.OooO.OooO0Oo(sidecarWindowLayoutInfo, sidecarWindowLayoutInfo2)) {
            return true;
        }
        if (sidecarWindowLayoutInfo == null || sidecarWindowLayoutInfo2 == null) {
            return false;
        }
        return OooO0OO(Oooo0.OooO0OO(sidecarWindowLayoutInfo), Oooo0.OooO0OO(sidecarWindowLayoutInfo2));
    }

    public final ArrayList OooO0o(List list, SidecarDeviceState sidecarDeviceState) {
        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(list, "sidecarDisplayFeatures");
        ArrayList arrayList = new ArrayList();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            OooOo oooOoOooO0oO = OooO0oO((SidecarDisplayFeature) it.next(), sidecarDeviceState);
            if (oooOoOooO0oO != null) {
                arrayList.add(oooOoOooO0oO);
            }
        }
        return arrayList;
    }

    public final o000000 OooO0o0(SidecarWindowLayoutInfo sidecarWindowLayoutInfo, SidecarDeviceState sidecarDeviceState) {
        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(sidecarDeviceState, "state");
        if (sidecarWindowLayoutInfo == null) {
            return new o000000(o000Oo0.OooOO0O.OooOOo0());
        }
        SidecarDeviceState sidecarDeviceState2 = new SidecarDeviceState();
        Oooo0.OooO0Oo(sidecarDeviceState2, Oooo0.OooO0O0(sidecarDeviceState));
        return new o000000(OooO0o(Oooo0.OooO0OO(sidecarWindowLayoutInfo), sidecarDeviceState2));
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0057, code lost:
    
        if (r6 == 4) goto L23;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final androidx.window.layout.OooOo OooO0oO(androidx.window.sidecar.SidecarDisplayFeature r5, androidx.window.sidecar.SidecarDeviceState r6) {
        /*
            r4 = this;
            java.lang.String r0 = "feature"
            com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(r5, r0)
            int r0 = androidx.window.core.OooOO0.f5349OooO00o
            androidx.window.core.SpecificationComputer$VerificationMode r0 = r4.f5392OooO00o
            androidx.window.core.OooOO0O r0 = p042OooooOo.o00O0O0.OooOooo(r5, r0)
            java.lang.String r1 = "Type must be either TYPE_FOLD or TYPE_HINGE"
            androidx.window.layout.SidecarAdapter$translate$checkedFeature$1 r2 = new o00O0OOO.OooOo() { // from class: androidx.window.layout.SidecarAdapter$translate$checkedFeature$1
                static {
                    /*
                        androidx.window.layout.SidecarAdapter$translate$checkedFeature$1 r0 = new androidx.window.layout.SidecarAdapter$translate$checkedFeature$1
                        r0.<init>()
                        
                        // error: 0x0005: SPUT (r0 I:androidx.window.layout.SidecarAdapter$translate$checkedFeature$1) androidx.window.layout.SidecarAdapter$translate$checkedFeature$1.INSTANCE androidx.window.layout.SidecarAdapter$translate$checkedFeature$1
                        return
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$1.<clinit>():void");
                }

                {
                    /*
                        r1 = this;
                        r0 = 1
                        r1.<init>(r0)
                        return
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$1.<init>():void");
                }

                @Override // o00O0OOO.OooOo
                public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object r1) {
                    /*
                        r0 = this;
                        androidx.window.sidecar.SidecarDisplayFeature r1 = (androidx.window.sidecar.SidecarDisplayFeature) r1
                        java.lang.Boolean r1 = r0.invoke(r1)
                        return r1
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$1.invoke(java.lang.Object):java.lang.Object");
                }

                @Override // o00O0OOO.OooOo
                public final java.lang.Boolean invoke(androidx.window.sidecar.SidecarDisplayFeature r3) {
                    /*
                        r2 = this;
                        java.lang.String r0 = "$this$require"
                        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(r3, r0)
                        int r0 = r3.getType()
                        r1 = 1
                        if (r0 == r1) goto L15
                        int r3 = r3.getType()
                        r0 = 2
                        if (r3 != r0) goto L14
                        goto L15
                    L14:
                        r1 = 0
                    L15:
                        java.lang.Boolean r3 = java.lang.Boolean.valueOf(r1)
                        return r3
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$1.invoke(androidx.window.sidecar.SidecarDisplayFeature):java.lang.Boolean");
                }
            }
            androidx.window.core.OooOO0 r0 = r0.OooO0OO(r1, r2)
            java.lang.String r1 = "Feature bounds must not be 0"
            androidx.window.layout.SidecarAdapter$translate$checkedFeature$2 r2 = new o00O0OOO.OooOo() { // from class: androidx.window.layout.SidecarAdapter$translate$checkedFeature$2
                static {
                    /*
                        androidx.window.layout.SidecarAdapter$translate$checkedFeature$2 r0 = new androidx.window.layout.SidecarAdapter$translate$checkedFeature$2
                        r0.<init>()
                        
                        // error: 0x0005: SPUT (r0 I:androidx.window.layout.SidecarAdapter$translate$checkedFeature$2) androidx.window.layout.SidecarAdapter$translate$checkedFeature$2.INSTANCE androidx.window.layout.SidecarAdapter$translate$checkedFeature$2
                        return
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$2.<clinit>():void");
                }

                {
                    /*
                        r1 = this;
                        r0 = 1
                        r1.<init>(r0)
                        return
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$2.<init>():void");
                }

                @Override // o00O0OOO.OooOo
                public final java.lang.Boolean invoke(androidx.window.sidecar.SidecarDisplayFeature r2) {
                    /*
                        r1 = this;
                        java.lang.String r0 = "$this$require"
                        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(r2, r0)
                        android.graphics.Rect r0 = r2.getRect()
                        int r0 = r0.width()
                        if (r0 != 0) goto L1c
                        android.graphics.Rect r2 = r2.getRect()
                        int r2 = r2.height()
                        if (r2 == 0) goto L1a
                        goto L1c
                    L1a:
                        r2 = 0
                        goto L1d
                    L1c:
                        r2 = 1
                    L1d:
                        java.lang.Boolean r2 = java.lang.Boolean.valueOf(r2)
                        return r2
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$2.invoke(androidx.window.sidecar.SidecarDisplayFeature):java.lang.Boolean");
                }

                @Override // o00O0OOO.OooOo
                public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object r1) {
                    /*
                        r0 = this;
                        androidx.window.sidecar.SidecarDisplayFeature r1 = (androidx.window.sidecar.SidecarDisplayFeature) r1
                        java.lang.Boolean r1 = r0.invoke(r1)
                        return r1
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$2.invoke(java.lang.Object):java.lang.Object");
                }
            }
            androidx.window.core.OooOO0 r0 = r0.OooO0OO(r1, r2)
            java.lang.String r1 = "TYPE_FOLD must have 0 area"
            androidx.window.layout.SidecarAdapter$translate$checkedFeature$3 r2 = new o00O0OOO.OooOo() { // from class: androidx.window.layout.SidecarAdapter$translate$checkedFeature$3
                static {
                    /*
                        androidx.window.layout.SidecarAdapter$translate$checkedFeature$3 r0 = new androidx.window.layout.SidecarAdapter$translate$checkedFeature$3
                        r0.<init>()
                        
                        // error: 0x0005: SPUT (r0 I:androidx.window.layout.SidecarAdapter$translate$checkedFeature$3) androidx.window.layout.SidecarAdapter$translate$checkedFeature$3.INSTANCE androidx.window.layout.SidecarAdapter$translate$checkedFeature$3
                        return
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$3.<clinit>():void");
                }

                {
                    /*
                        r1 = this;
                        r0 = 1
                        r1.<init>(r0)
                        return
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$3.<init>():void");
                }

                @Override // o00O0OOO.OooOo
                public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object r1) {
                    /*
                        r0 = this;
                        androidx.window.sidecar.SidecarDisplayFeature r1 = (androidx.window.sidecar.SidecarDisplayFeature) r1
                        java.lang.Boolean r1 = r0.invoke(r1)
                        return r1
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$3.invoke(java.lang.Object):java.lang.Object");
                }

                @Override // o00O0OOO.OooOo
                public final java.lang.Boolean invoke(androidx.window.sidecar.SidecarDisplayFeature r3) {
                    /*
                        r2 = this;
                        java.lang.String r0 = "$this$require"
                        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(r3, r0)
                        int r0 = r3.getType()
                        r1 = 1
                        if (r0 != r1) goto L22
                        android.graphics.Rect r0 = r3.getRect()
                        int r0 = r0.width()
                        if (r0 == 0) goto L22
                        android.graphics.Rect r3 = r3.getRect()
                        int r3 = r3.height()
                        if (r3 != 0) goto L21
                        goto L22
                    L21:
                        r1 = 0
                    L22:
                        java.lang.Boolean r3 = java.lang.Boolean.valueOf(r1)
                        return r3
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$3.invoke(androidx.window.sidecar.SidecarDisplayFeature):java.lang.Boolean");
                }
            }
            androidx.window.core.OooOO0 r0 = r0.OooO0OO(r1, r2)
            java.lang.String r1 = "Feature be pinned to either left or top"
            androidx.window.layout.SidecarAdapter$translate$checkedFeature$4 r2 = new o00O0OOO.OooOo() { // from class: androidx.window.layout.SidecarAdapter$translate$checkedFeature$4
                static {
                    /*
                        androidx.window.layout.SidecarAdapter$translate$checkedFeature$4 r0 = new androidx.window.layout.SidecarAdapter$translate$checkedFeature$4
                        r0.<init>()
                        
                        // error: 0x0005: SPUT (r0 I:androidx.window.layout.SidecarAdapter$translate$checkedFeature$4) androidx.window.layout.SidecarAdapter$translate$checkedFeature$4.INSTANCE androidx.window.layout.SidecarAdapter$translate$checkedFeature$4
                        return
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$4.<clinit>():void");
                }

                {
                    /*
                        r1 = this;
                        r0 = 1
                        r1.<init>(r0)
                        return
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$4.<init>():void");
                }

                @Override // o00O0OOO.OooOo
                public /* bridge */ /* synthetic */ java.lang.Object invoke(java.lang.Object r1) {
                    /*
                        r0 = this;
                        androidx.window.sidecar.SidecarDisplayFeature r1 = (androidx.window.sidecar.SidecarDisplayFeature) r1
                        java.lang.Boolean r1 = r0.invoke(r1)
                        return r1
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$4.invoke(java.lang.Object):java.lang.Object");
                }

                @Override // o00O0OOO.OooOo
                public final java.lang.Boolean invoke(androidx.window.sidecar.SidecarDisplayFeature r2) {
                    /*
                        r1 = this;
                        java.lang.String r0 = "$this$require"
                        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(r2, r0)
                        android.graphics.Rect r0 = r2.getRect()
                        int r0 = r0.left
                        if (r0 == 0) goto L18
                        android.graphics.Rect r2 = r2.getRect()
                        int r2 = r2.top
                        if (r2 != 0) goto L16
                        goto L18
                    L16:
                        r2 = 0
                        goto L19
                    L18:
                        r2 = 1
                    L19:
                        java.lang.Boolean r2 = java.lang.Boolean.valueOf(r2)
                        return r2
                    */
                    throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.SidecarAdapter$translate$checkedFeature$4.invoke(androidx.window.sidecar.SidecarDisplayFeature):java.lang.Boolean");
                }
            }
            androidx.window.core.OooOO0 r0 = r0.OooO0OO(r1, r2)
            java.lang.Object r0 = r0.OooO00o()
            androidx.window.sidecar.SidecarDisplayFeature r0 = (androidx.window.sidecar.SidecarDisplayFeature) r0
            r1 = 0
            if (r0 != 0) goto L37
            return r1
        L37:
            int r0 = r0.getType()
            r2 = 2
            r3 = 1
            if (r0 == r3) goto L45
            if (r0 == r2) goto L42
            return r1
        L42:
            androidx.window.layout.OooOo00 r0 = androidx.window.layout.OooOo00.f5381OooO0OO
            goto L47
        L45:
            androidx.window.layout.OooOo00 r0 = androidx.window.layout.OooOo00.f5380OooO0O0
        L47:
            int r6 = androidx.window.layout.Oooo0.OooO0O0(r6)
            if (r6 == 0) goto L70
            if (r6 == r3) goto L70
            if (r6 == r2) goto L5a
            androidx.window.layout.OooOOO r2 = androidx.window.layout.OooOOO.f5371OooO0O0
            r3 = 3
            if (r6 == r3) goto L5c
            r3 = 4
            if (r6 == r3) goto L70
            goto L5c
        L5a:
            androidx.window.layout.OooOOO r2 = androidx.window.layout.OooOOO.f5372OooO0OO
        L5c:
            androidx.window.layout.OooOo r6 = new androidx.window.layout.OooOo
            androidx.window.core.OooO0O0 r1 = new androidx.window.core.OooO0O0
            android.graphics.Rect r5 = r5.getRect()
            java.lang.String r3 = "feature.rect"
            com.github.doyaaaaaken.kotlincsv.client.OooO.OooOO0o(r5, r3)
            r1.<init>(r5)
            r6.<init>(r1, r0, r2)
            return r6
        L70:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.window.layout.o000oOoO.OooO0oO(androidx.window.sidecar.SidecarDisplayFeature, androidx.window.sidecar.SidecarDeviceState):androidx.window.layout.OooOo");
    }
}
