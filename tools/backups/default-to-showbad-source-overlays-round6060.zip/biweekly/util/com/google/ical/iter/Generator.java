package biweekly.util.com.google.ical.iter;

import biweekly.util.com.google.ical.util.DTBuilder;

abstract class Generator {

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\biweekly\util\com\google\ical\iter\Generator$IteratorShortCircuitingException.smali */
    public static class IteratorShortCircuitingException extends Exception {
        private static final IteratorShortCircuitingException INSTANCE = new IteratorShortCircuitingException();

        private IteratorShortCircuitingException() {
            setStackTrace(new StackTraceElement[0]);
        }

        public static IteratorShortCircuitingException instance() {
            return INSTANCE;
        }
    }

    static {
        IteratorShortCircuitingException.instance();
    }

    public abstract boolean generate(DTBuilder dTBuilder);
}
