package com.huawei.hms.analytics;

import biweekly.parameter.ICalParameters;
import com.huawei.agconnect.common.api.HaBridge;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

public interface aq {
    public static final List<String> fgh;
    public static final String[] ghi;
    public static final List<String> hij;
    public static final String[] ijk;
    public static final Pattern lmn = Pattern.compile("^[a-zA-Z0-9_-]+(\\s+[a-zA-Z0-9_-]+)*$");
    public static final Pattern klm = Pattern.compile("[a-zA-Z_][a-zA-Z0-9_]*|[\\$][a-zA-Z0-9]*");
    public static final Pattern ikl = Pattern.compile("[a-zA-Z][a-zA-Z0-9_]*|[\\$][a-zA-Z0-9]*");

    static {
        String[] strArr = {ICalParameters.CN, "DE", "SG", "RU"};
        ijk = strArr;
        hij = Collections.unmodifiableList(Arrays.asList(strArr));
        String[] strArr2 = {"AGC_TAG", HaBridge.HA_SERVICE_TAG_CRASH, HaBridge.HA_SERVICE_TAG_ABTEST, HaBridge.HA_SERVICE_TAG_APP_LINKING, HaBridge.HA_SERVICE_TAG_CONFIG, HaBridge.HA_SERVICE_TAG_IAM};
        ghi = strArr2;
        fgh = Collections.unmodifiableList(Arrays.asList(strArr2));
    }
}
