package com.huawei.hms.opendevice;

import android.content.Context;
import android.text.TextUtils;
import com.github.doyaaaaaken.kotlincsv.client.OooO;
import com.huawei.hms.support.log.HMSLog;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.GeneralSecurityException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import o00O0000.OooO00o;

public abstract class g {

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\opendevice\g$a.smali */
    public enum a {
        GET("GET"),
        POST("POST");

        private String a;

        a(String str) {
            this.a = str;
        }

        public String a() {
            return this.a;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v0, types: [java.lang.CharSequence, java.lang.String] */
    /* JADX WARN: Type inference failed for: r10v1 */
    /* JADX WARN: Type inference failed for: r10v10, types: [java.io.Closeable] */
    /* JADX WARN: Type inference failed for: r10v11 */
    /* JADX WARN: Type inference failed for: r10v13, types: [java.io.BufferedOutputStream, java.io.Closeable, java.io.OutputStream] */
    /* JADX WARN: Type inference failed for: r10v14 */
    /* JADX WARN: Type inference failed for: r10v15 */
    /* JADX WARN: Type inference failed for: r10v16 */
    /* JADX WARN: Type inference failed for: r10v17 */
    /* JADX WARN: Type inference failed for: r10v18 */
    /* JADX WARN: Type inference failed for: r10v2 */
    /* JADX WARN: Type inference failed for: r10v3 */
    /* JADX WARN: Type inference failed for: r10v4 */
    /* JADX WARN: Type inference failed for: r10v5 */
    /* JADX WARN: Type inference failed for: r10v6, types: [java.io.Closeable] */
    /* JADX WARN: Type inference failed for: r10v7 */
    /* JADX WARN: Type inference failed for: r10v8 */
    /* JADX WARN: Type inference failed for: r10v9 */
    /* JADX WARN: Type inference failed for: r11v0, types: [java.lang.CharSequence, java.lang.String] */
    /* JADX WARN: Type inference failed for: r11v10 */
    /* JADX WARN: Type inference failed for: r11v11 */
    /* JADX WARN: Type inference failed for: r11v12, types: [java.io.Closeable] */
    /* JADX WARN: Type inference failed for: r11v13 */
    /* JADX WARN: Type inference failed for: r11v16 */
    /* JADX WARN: Type inference failed for: r11v17 */
    /* JADX WARN: Type inference failed for: r11v18 */
    /* JADX WARN: Type inference failed for: r11v19 */
    /* JADX WARN: Type inference failed for: r11v2 */
    /* JADX WARN: Type inference failed for: r11v20 */
    /* JADX WARN: Type inference failed for: r11v21 */
    /* JADX WARN: Type inference failed for: r11v22 */
    /* JADX WARN: Type inference failed for: r11v23 */
    /* JADX WARN: Type inference failed for: r11v29, types: [java.io.Closeable, java.io.InputStream] */
    /* JADX WARN: Type inference failed for: r11v3 */
    /* JADX WARN: Type inference failed for: r11v31 */
    /* JADX WARN: Type inference failed for: r11v32 */
    /* JADX WARN: Type inference failed for: r11v33 */
    /* JADX WARN: Type inference failed for: r11v34 */
    /* JADX WARN: Type inference failed for: r11v35 */
    /* JADX WARN: Type inference failed for: r11v36 */
    /* JADX WARN: Type inference failed for: r11v37 */
    /* JADX WARN: Type inference failed for: r11v38 */
    /* JADX WARN: Type inference failed for: r11v39 */
    /* JADX WARN: Type inference failed for: r11v5 */
    /* JADX WARN: Type inference failed for: r11v6 */
    /* JADX WARN: Type inference failed for: r11v7 */
    /* JADX WARN: Type inference failed for: r11v8, types: [java.io.Closeable] */
    /* JADX WARN: Type inference failed for: r11v9 */
    /* JADX WARN: Type inference failed for: r12v0, types: [java.util.Map, java.util.Map<java.lang.String, java.lang.String>] */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v10, types: [java.io.Closeable] */
    /* JADX WARN: Type inference failed for: r12v11 */
    /* JADX WARN: Type inference failed for: r12v15 */
    /* JADX WARN: Type inference failed for: r12v16 */
    /* JADX WARN: Type inference failed for: r12v17 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v20, types: [java.io.BufferedInputStream, java.io.Closeable, java.io.InputStream] */
    /* JADX WARN: Type inference failed for: r12v21 */
    /* JADX WARN: Type inference failed for: r12v22 */
    /* JADX WARN: Type inference failed for: r12v23 */
    /* JADX WARN: Type inference failed for: r12v24 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v6 */
    /* JADX WARN: Type inference failed for: r12v7 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9 */
    /* JADX WARN: Type inference failed for: r6v0 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v2 */
    /* JADX WARN: Type inference failed for: r6v3, types: [java.io.Closeable] */
    /* JADX WARN: Type inference failed for: r6v4 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r9v0, types: [android.content.Context] */
    /* JADX WARN: Type inference failed for: r9v10 */
    /* JADX WARN: Type inference failed for: r9v11 */
    /* JADX WARN: Type inference failed for: r9v12, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r9v13 */
    /* JADX WARN: Type inference failed for: r9v14 */
    /* JADX WARN: Type inference failed for: r9v15 */
    /* JADX WARN: Type inference failed for: r9v16, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r9v17 */
    /* JADX WARN: Type inference failed for: r9v18, types: [java.net.HttpURLConnection, java.net.URLConnection] */
    /* JADX WARN: Type inference failed for: r9v19 */
    /* JADX WARN: Type inference failed for: r9v2 */
    /* JADX WARN: Type inference failed for: r9v20 */
    /* JADX WARN: Type inference failed for: r9v21 */
    /* JADX WARN: Type inference failed for: r9v22 */
    /* JADX WARN: Type inference failed for: r9v23 */
    /* JADX WARN: Type inference failed for: r9v24 */
    /* JADX WARN: Type inference failed for: r9v25 */
    /* JADX WARN: Type inference failed for: r9v26 */
    /* JADX WARN: Type inference failed for: r9v3 */
    /* JADX WARN: Type inference failed for: r9v4 */
    /* JADX WARN: Type inference failed for: r9v5 */
    /* JADX WARN: Type inference failed for: r9v6 */
    /* JADX WARN: Type inference failed for: r9v7 */
    /* JADX WARN: Type inference failed for: r9v8 */
    /* JADX WARN: Type inference failed for: r9v9 */
    public static String a(Context context, String str, String str2, Map<String, String> map) throws Throwable {
        Throwable th;
        ?? r9;
        Object obj;
        ?? A;
        ?? bufferedInputStream;
        ?? errorStream;
        ?? bufferedOutputStream;
        ?? r11;
        ?? r10;
        ?? r12;
        Throwable th2;
        ?? r6 = 0;
        ?? r7 = 0;
        if (str2 == 0 || TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            return null;
        }
        int responseCode = -1;
        try {
            try {
                A = a((Context) context, (String) str, (Map<String, String>) map, a.POST.a());
                if (A == 0) {
                    p.a((HttpURLConnection) A);
                    HMSLog.i("PushHttpClient", "close connection");
                    return null;
                }
                try {
                    bufferedOutputStream = new BufferedOutputStream(A.getOutputStream());
                    try {
                        bufferedOutputStream.write(str2.getBytes("UTF-8"));
                        bufferedOutputStream.flush();
                        responseCode = A.getResponseCode();
                        HMSLog.d("PushHttpClient", "http post response code: " + responseCode);
                        errorStream = responseCode >= 400 ? A.getErrorStream() : A.getInputStream();
                        try {
                            bufferedInputStream = new BufferedInputStream(errorStream);
                            try {
                                String strA = p.a((InputStream) bufferedInputStream);
                                OooO.OooOOOo(bufferedOutputStream);
                                OooO.OooOOOo(errorStream);
                                OooO.OooOOOo(bufferedInputStream);
                                p.a((HttpURLConnection) A);
                                HMSLog.i("PushHttpClient", "close connection");
                                return strA;
                            } catch (IOException unused) {
                                HMSLog.w("PushHttpClient", "http execute encounter IOException - http code:" + responseCode);
                                context = A;
                                str = bufferedOutputStream;
                                str2 = errorStream;
                                map = bufferedInputStream;
                                OooO.OooOOOo(str);
                                OooO.OooOOOo(str2);
                                OooO.OooOOOo(map);
                                p.a((HttpURLConnection) context);
                                HMSLog.i("PushHttpClient", "close connection");
                                return null;
                            } catch (RuntimeException unused2) {
                                HMSLog.w("PushHttpClient", "http execute encounter RuntimeException - http code:" + responseCode);
                                context = A;
                                str = bufferedOutputStream;
                                str2 = errorStream;
                                map = bufferedInputStream;
                                OooO.OooOOOo(str);
                                OooO.OooOOOo(str2);
                                OooO.OooOOOo(map);
                                p.a((HttpURLConnection) context);
                                HMSLog.i("PushHttpClient", "close connection");
                                return null;
                            } catch (Exception unused3) {
                                HMSLog.w("PushHttpClient", "http execute encounter unknown exception - http code:" + responseCode);
                                context = A;
                                str = bufferedOutputStream;
                                str2 = errorStream;
                                map = bufferedInputStream;
                                OooO.OooOOOo(str);
                                OooO.OooOOOo(str2);
                                OooO.OooOOOo(map);
                                p.a((HttpURLConnection) context);
                                HMSLog.i("PushHttpClient", "close connection");
                                return null;
                            } catch (Throwable th3) {
                                th = th3;
                                r7 = bufferedInputStream;
                                r12 = A;
                                r10 = bufferedOutputStream;
                                r11 = errorStream;
                                OooO.OooOOOo(r10);
                                OooO.OooOOOo(r11);
                                OooO.OooOOOo(r7);
                                p.a((HttpURLConnection) r12);
                                HMSLog.i("PushHttpClient", "close connection");
                                throw th;
                            }
                        } catch (IOException unused4) {
                            bufferedInputStream = 0;
                            HMSLog.w("PushHttpClient", "http execute encounter IOException - http code:" + responseCode);
                            context = A;
                            str = bufferedOutputStream;
                            str2 = errorStream;
                            map = bufferedInputStream;
                            OooO.OooOOOo(str);
                            OooO.OooOOOo(str2);
                            OooO.OooOOOo(map);
                            p.a((HttpURLConnection) context);
                            HMSLog.i("PushHttpClient", "close connection");
                            return null;
                        } catch (RuntimeException unused5) {
                            bufferedInputStream = 0;
                            HMSLog.w("PushHttpClient", "http execute encounter RuntimeException - http code:" + responseCode);
                            context = A;
                            str = bufferedOutputStream;
                            str2 = errorStream;
                            map = bufferedInputStream;
                            OooO.OooOOOo(str);
                            OooO.OooOOOo(str2);
                            OooO.OooOOOo(map);
                            p.a((HttpURLConnection) context);
                            HMSLog.i("PushHttpClient", "close connection");
                            return null;
                        } catch (Exception unused6) {
                            bufferedInputStream = 0;
                            HMSLog.w("PushHttpClient", "http execute encounter unknown exception - http code:" + responseCode);
                            context = A;
                            str = bufferedOutputStream;
                            str2 = errorStream;
                            map = bufferedInputStream;
                            OooO.OooOOOo(str);
                            OooO.OooOOOo(str2);
                            OooO.OooOOOo(map);
                            p.a((HttpURLConnection) context);
                            HMSLog.i("PushHttpClient", "close connection");
                            return null;
                        } catch (Throwable th4) {
                            th2 = th4;
                            th = th2;
                            r12 = A;
                            r10 = bufferedOutputStream;
                            r11 = errorStream;
                            OooO.OooOOOo(r10);
                            OooO.OooOOOo(r11);
                            OooO.OooOOOo(r7);
                            p.a((HttpURLConnection) r12);
                            HMSLog.i("PushHttpClient", "close connection");
                            throw th;
                        }
                    } catch (IOException unused7) {
                        errorStream = 0;
                    } catch (RuntimeException unused8) {
                        errorStream = 0;
                    } catch (Exception unused9) {
                        errorStream = 0;
                    } catch (Throwable th5) {
                        th2 = th5;
                        errorStream = 0;
                    }
                } catch (IOException unused10) {
                    bufferedOutputStream = 0;
                    errorStream = 0;
                    bufferedInputStream = 0;
                    HMSLog.w("PushHttpClient", "http execute encounter IOException - http code:" + responseCode);
                    context = A;
                    str = bufferedOutputStream;
                    str2 = errorStream;
                    map = bufferedInputStream;
                    OooO.OooOOOo(str);
                    OooO.OooOOOo(str2);
                    OooO.OooOOOo(map);
                    p.a((HttpURLConnection) context);
                    HMSLog.i("PushHttpClient", "close connection");
                    return null;
                } catch (RuntimeException unused11) {
                    bufferedOutputStream = 0;
                    errorStream = 0;
                    bufferedInputStream = 0;
                    HMSLog.w("PushHttpClient", "http execute encounter RuntimeException - http code:" + responseCode);
                    context = A;
                    str = bufferedOutputStream;
                    str2 = errorStream;
                    map = bufferedInputStream;
                    OooO.OooOOOo(str);
                    OooO.OooOOOo(str2);
                    OooO.OooOOOo(map);
                    p.a((HttpURLConnection) context);
                    HMSLog.i("PushHttpClient", "close connection");
                    return null;
                } catch (Exception unused12) {
                    bufferedOutputStream = 0;
                    errorStream = 0;
                    bufferedInputStream = 0;
                    HMSLog.w("PushHttpClient", "http execute encounter unknown exception - http code:" + responseCode);
                    context = A;
                    str = bufferedOutputStream;
                    str2 = errorStream;
                    map = bufferedInputStream;
                    OooO.OooOOOo(str);
                    OooO.OooOOOo(str2);
                    OooO.OooOOOo(map);
                    p.a((HttpURLConnection) context);
                    HMSLog.i("PushHttpClient", "close connection");
                    return null;
                } catch (Throwable th6) {
                    th = th6;
                    obj = null;
                    r9 = A;
                    bufferedInputStream = obj;
                    A = r9;
                    errorStream = obj;
                    bufferedOutputStream = r6;
                    r7 = bufferedInputStream;
                    r12 = A;
                    r10 = bufferedOutputStream;
                    r11 = errorStream;
                    OooO.OooOOOo(r10);
                    OooO.OooOOOo(r11);
                    OooO.OooOOOo(r7);
                    p.a((HttpURLConnection) r12);
                    HMSLog.i("PushHttpClient", "close connection");
                    throw th;
                }
            } catch (Throwable th7) {
                th = th7;
                r6 = str;
                A = context;
                errorStream = str2;
                bufferedInputStream = map;
                bufferedOutputStream = r6;
                r7 = bufferedInputStream;
                r12 = A;
                r10 = bufferedOutputStream;
                r11 = errorStream;
                OooO.OooOOOo(r10);
                OooO.OooOOOo(r11);
                OooO.OooOOOo(r7);
                p.a((HttpURLConnection) r12);
                HMSLog.i("PushHttpClient", "close connection");
                throw th;
            }
        } catch (IOException unused13) {
            A = 0;
        } catch (RuntimeException unused14) {
            A = 0;
        } catch (Exception unused15) {
            A = 0;
        } catch (Throwable th8) {
            th = th8;
            r9 = 0;
            obj = null;
        }
    }

    private static HttpURLConnection a(Context context, String str, Map<String, String> map, String str2) throws Exception {
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
        a(context, httpURLConnection);
        httpURLConnection.setRequestMethod(str2);
        httpURLConnection.setConnectTimeout(15000);
        httpURLConnection.setReadTimeout(15000);
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setDoInput(true);
        httpURLConnection.setRequestProperty("Content-type", "application/json; charset=UTF-8");
        httpURLConnection.setRequestProperty("Connection", "close");
        if (map != null && map.size() >= 1) {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                String key = entry.getKey();
                if (key != null && !TextUtils.isEmpty(key)) {
                    httpURLConnection.setRequestProperty(key, URLEncoder.encode(entry.getValue() == null ? "" : entry.getValue(), "UTF-8"));
                }
            }
        }
        return httpURLConnection;
    }

    private static void a(Context context, HttpURLConnection httpURLConnection) throws Exception {
        OooO00o oooO00oOooO0O0;
        if (httpURLConnection instanceof HttpsURLConnection) {
            HttpsURLConnection httpsURLConnection = (HttpsURLConnection) httpURLConnection;
            try {
                oooO00oOooO0O0 = OooO00o.OooO0O0(context);
            } catch (IOException unused) {
                HMSLog.w("PushHttpClient", "Get SocketFactory IO Exception.");
                oooO00oOooO0O0 = null;
            } catch (IllegalAccessException unused2) {
                HMSLog.w("PushHttpClient", "Get SocketFactory Illegal Access Exception.");
                oooO00oOooO0O0 = null;
            } catch (IllegalArgumentException unused3) {
                HMSLog.w("PushHttpClient", "Get SocketFactory Illegal Argument Exception.");
                oooO00oOooO0O0 = null;
            } catch (KeyStoreException unused4) {
                HMSLog.w("PushHttpClient", "Get SocketFactory Key Store exception.");
                oooO00oOooO0O0 = null;
            } catch (NoSuchAlgorithmException unused5) {
                HMSLog.w("PushHttpClient", "Get SocketFactory Algorithm Exception.");
                oooO00oOooO0O0 = null;
            } catch (GeneralSecurityException unused6) {
                HMSLog.w("PushHttpClient", "Get SocketFactory General Security Exception.");
                oooO00oOooO0O0 = null;
            }
            if (oooO00oOooO0O0 != null) {
                httpsURLConnection.setSSLSocketFactory(oooO00oOooO0O0);
                httpsURLConnection.setHostnameVerifier(OooO00o.f11131OooO0Oo);
                return;
            }
            throw new Exception("No ssl socket factory set.");
        }
    }
}
