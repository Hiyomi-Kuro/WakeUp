package com.huawei.hms.analytics;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import biweekly.parameter.ICalParameters;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.framework.config.IConfig;

public final class aj implements m.lmn {
    private static ah klm;
    private static final aj lmn = new aj();

    private static void klm(String str, String str2, String str3) {
        av.lmn().lmn.h = str;
        av.lmn().lmn.j = str2;
        av.lmn().lmn.i = str3;
    }

    /* JADX WARN: Code duplicated, block: B:72:0x0162  */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0048, code lost:
    
        if (com.huawei.hms.analytics.av.lmn().lmn.m == false) goto L12;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void lmn(Context context, IConfig iConfig) {
        HiLog.d("oaidMg", "start get oaid");
        ah acVar = null;
        if (!ICalParameters.CN.equals(iConfig.getSite()) && !"RU".equals(iConfig.getSite()) && !"SG".equals(iConfig.getSite())) {
            if ("DE".equals(iConfig.getSite())) {
                new ch(iConfig).klm();
            }
            klm(null, null, null);
            HiLog.i("oaidMg", "The current config does not support oaid collection.");
            return;
        }
        if (!av.lmn().lmn.k) {
            klm("", "", "");
            HiLog.i("oaidMg", "Stopped collecting oaid.");
            return;
        }
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (jCurrentTimeMillis - av.lmn().lmn.w <= 86400000) {
            return;
        }
        av.lmn().lmn.w = jCurrentTimeMillis;
        ah ahVar = klm;
        if (ahVar != null) {
            acVar = ahVar;
        } else if (ad.lmn() || ad.klm()) {
            acVar = new ac(context, lmn);
        } else {
            String str = Build.MANUFACTURER;
            if ("COOLPAD".equalsIgnoreCase(str) || "XIAOLAJIAO".equalsIgnoreCase(str) || "GIONEE".equalsIgnoreCase(str)) {
                acVar = new ac(context, lmn);
            } else if (ad.ikl() || "ONEPLUS".equalsIgnoreCase(str)) {
                acVar = new ak(context, lmn);
            } else if ("MOTOROLA".equalsIgnoreCase(str)) {
                acVar = new ae(context, lmn);
            } else if (ad.ijk() || ad.ghi()) {
                acVar = new an(context, lmn);
            } else if ("NUBIA".equalsIgnoreCase(str)) {
                acVar = new ag(context, lmn);
            } else if ("DOOV".equalsIgnoreCase(str) || "FREEMEOS".equalsIgnoreCase(str) || !TextUtils.isEmpty(dt.lmn("ro.build.freeme.label", ""))) {
                acVar = new ac(context, lmn);
            } else if ("SAMSUNG".equalsIgnoreCase(str)) {
                acVar = new al(context, lmn);
            } else if (ad.hij()) {
                acVar = new am(context, lmn);
            } else if ("MEIZU".equalsIgnoreCase(str) || "FLYME".equals(Build.DISPLAY)) {
                acVar = new af(context, lmn);
            }
        }
        klm = acVar;
        if (acVar == null) {
            klm("", "", "");
        } else if (acVar.klm()) {
            klm.lmn();
        } else {
            klm.lmn("No support collect oid");
        }
    }

    @Override // com.huawei.hms.analytics.m.lmn
    public final void lmn(String str, String str2, String str3) {
        if (TextUtils.isEmpty(str3)) {
            str = dl.lmn().klm();
            str2 = "";
            str3 = com.huawei.agconnect.credential.obs.c.a;
        }
        klm(str, str2, str3);
    }
}
