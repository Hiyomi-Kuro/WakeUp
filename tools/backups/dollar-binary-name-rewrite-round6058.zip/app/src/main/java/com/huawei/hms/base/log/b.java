package com.huawei.hms.base.log;

import android.content.Context;
import android.util.Log;

public class b {
    private String b;
    private int a = 4;
    private d c = new c();

    private void b() {
    }

    public d a() {
        return this.c;
    }

    private e b(int i, String str, String str2, Throwable th) {
        e eVar = new e(8, this.b, i, str);
        eVar.a(str2);
        eVar.a(th);
        return eVar;
    }

    public void a(d dVar) {
        this.c = dVar;
    }

    public boolean a(int i) {
        return i >= this.a;
    }

    public void a(Context context, int i, String str) {
        this.a = i;
        this.b = str;
        this.c.a(context, "HMSCore");
    }

    public void a(int i, String str, String str2, Throwable th) {
        try {
            if (a(i)) {
                e eVarB = b(i, str, str2, th);
                String str3 = eVarB.b() + eVarB.a();
                this.c.a(str3, i, str, str2 + '\n' + Log.getStackTraceString(th));
            }
        } catch (OutOfMemoryError unused) {
            b();
        }
    }

    public void a(int i, String str, String str2) {
        try {
            if (a(i)) {
                e eVarB = b(i, str, str2, null);
                this.c.a(eVarB.b() + eVarB.a(), i, str, str2);
            }
        } catch (OutOfMemoryError unused) {
            b();
        }
    }

    public void a(String str, String str2) {
        try {
            e eVarB = b(4, str, str2, null);
            this.c.a(eVarB.b() + '\n' + eVarB.a(), 4, str, str2);
        } catch (OutOfMemoryError unused) {
            b();
        }
    }
}
