package com.huawei.hms.framework.network.grs.e;

import OooO0OO.OooOo00;
import android.content.Context;
import android.text.TextUtils;
import com.huawei.hms.framework.common.Logger;
import com.huawei.hms.framework.common.hianalytics.CrashHianalyticsData;
import com.huawei.hms.framework.network.grs.GrsBaseInfo;
import com.huawei.hms.framework.network.grs.g.d;
import com.huawei.hms.framework.network.grs.g.h;
import com.huawei.hms.framework.network.grs.h.e;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class a {
    private static final String f = "a";
    private final Map<String, Map<String, Map<String, String>>> a = new ConcurrentHashMap(16);
    private final Map<String, Long> b = new ConcurrentHashMap(16);
    private final c c;
    private final c d;
    private final h e;

    public a(c cVar, c cVar2, h hVar) {
        this.d = cVar2;
        this.c = cVar;
        this.e = hVar;
        hVar.a(this);
    }

    public c a() {
        return this.c;
    }

    public h b() {
        return this.e;
    }

    public c c() {
        return this.d;
    }

    public Map<String, String> a(GrsBaseInfo grsBaseInfo, String str, b bVar, Context context) {
        Map<String, Map<String, String>> map = this.a.get(grsBaseInfo.getGrsParasKey(true, true, context));
        if (map == null || map.isEmpty()) {
            return new HashMap();
        }
        a(grsBaseInfo, bVar, context, str);
        return map.get(str);
    }

    public void b(GrsBaseInfo grsBaseInfo, Context context) {
        String grsParasKey = grsBaseInfo.getGrsParasKey(true, true, context);
        String strA = this.c.a(grsParasKey, "");
        String strA2 = this.c.a(grsParasKey + CrashHianalyticsData.TIME, "0");
        long j = 0;
        if (!TextUtils.isEmpty(strA2) && strA2.matches("\\d+")) {
            try {
                j = Long.parseLong(strA2);
            } catch (NumberFormatException e) {
                Logger.w(f, "convert urlParamKey from String to Long catch NumberFormatException.", e);
            }
        }
        this.a.put(grsParasKey, com.huawei.hms.framework.network.grs.a.a(strA));
        this.b.put(grsParasKey, Long.valueOf(j));
        a(grsBaseInfo, grsParasKey, context);
    }

    public void a(GrsBaseInfo grsBaseInfo, Context context) {
        String grsParasKey = grsBaseInfo.getGrsParasKey(true, true, context);
        this.c.b(grsParasKey + CrashHianalyticsData.TIME, "0");
        this.b.remove(grsParasKey + CrashHianalyticsData.TIME);
        this.a.remove(grsParasKey);
        this.e.a(grsParasKey);
    }

    private void a(GrsBaseInfo grsBaseInfo, b bVar, Context context, String str) {
        Long l = this.b.get(grsBaseInfo.getGrsParasKey(true, true, context));
        if (e.a(l)) {
            bVar.a(2);
            return;
        }
        if (e.a(l, 300000L)) {
            this.e.a(new com.huawei.hms.framework.network.grs.g.k.c(grsBaseInfo, context), null, str, this.d);
        }
        bVar.a(1);
    }

    public void a(GrsBaseInfo grsBaseInfo, d dVar, Context context, com.huawei.hms.framework.network.grs.g.k.c cVar) {
        if (dVar.f() == 2) {
            Logger.w(f, "update cache from server failed");
            return;
        }
        if (cVar.d().size() != 0) {
            this.c.b("geoipCountryCode", dVar.j());
            this.c.b("geoipCountryCodetime", dVar.a());
            return;
        }
        String grsParasKey = grsBaseInfo.getGrsParasKey(true, true, context);
        if (dVar.m()) {
            this.a.put(grsParasKey, com.huawei.hms.framework.network.grs.a.a(this.c.a(grsParasKey, "")));
        } else {
            this.c.b(grsParasKey, dVar.j());
            this.a.put(grsParasKey, com.huawei.hms.framework.network.grs.a.a(dVar.j()));
        }
        if (!TextUtils.isEmpty(dVar.e())) {
            this.c.b(OooOo00.OooOO0O(grsParasKey, "ETag"), dVar.e());
        }
        this.c.b(OooOo00.OooOO0O(grsParasKey, CrashHianalyticsData.TIME), dVar.a());
        this.b.put(grsParasKey, Long.valueOf(Long.parseLong(dVar.a())));
    }

    private void a(GrsBaseInfo grsBaseInfo, String str, Context context) {
        if (e.a(this.b.get(str), 300000L)) {
            this.e.a(new com.huawei.hms.framework.network.grs.g.k.c(grsBaseInfo, context), null, null, this.d);
        }
    }
}
