package androidx.room;

import android.content.Context;
import android.content.Intent;
import android.os.RemoteException;
import java.util.Arrays;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

public final class o00O0O {

    /* JADX INFO: renamed from: OooO, reason: collision with root package name */
    public final Oooo000 f5006OooO;

    /* JADX INFO: renamed from: OooO00o, reason: collision with root package name */
    public final String f5007OooO00o;

    /* JADX INFO: renamed from: OooO0O0, reason: collision with root package name */
    public final OooOo f5008OooO0O0;

    /* JADX INFO: renamed from: OooO0OO, reason: collision with root package name */
    public final Executor f5009OooO0OO;

    /* JADX INFO: renamed from: OooO0Oo, reason: collision with root package name */
    public int f5010OooO0Oo;

    /* JADX INFO: renamed from: OooO0o, reason: collision with root package name */
    public OooOOO f5011OooO0o;

    /* JADX INFO: renamed from: OooO0o0, reason: collision with root package name */
    public final Oooo0 f5012OooO0o0;

    /* JADX INFO: renamed from: OooO0oO, reason: collision with root package name */
    public final o000oOoO f5013OooO0oO;

    /* JADX INFO: renamed from: OooO0oo, reason: collision with root package name */
    public final AtomicBoolean f5014OooO0oo;

    /* JADX INFO: renamed from: OooOO0, reason: collision with root package name */
    public final Oooo000 f5015OooOO0;

    /* JADX WARN: Type inference failed for: r0v0, types: [androidx.room.Oooo000] */
    /* JADX WARN: Type inference failed for: r0v1, types: [androidx.room.Oooo000] */
    public o00O0O(Context context, String str, Intent intent, OooOo oooOo, Executor executor) {
        this.f5007OooO00o = str;
        this.f5008OooO0O0 = oooOo;
        this.f5009OooO0OO = executor;
        Context applicationContext = context.getApplicationContext();
        this.f5013OooO0oO = new o000oOoO(this);
        final int i = 0;
        this.f5014OooO0oo = new AtomicBoolean(false);
        o0OoOo0 o0oooo0 = new o0OoOo0(0, this);
        this.f5006OooO = new Runnable(this) { // from class: androidx.room.Oooo000

            /* JADX INFO: renamed from: OooOOO0, reason: collision with root package name */
            public final /* synthetic */ o00O0O f4992OooOOO0;

            {
                this.f4992OooOOO0 = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                OooOo00 oooOo00;
                switch (i) {
                    case 0:
                        o00O0O o00o0o = this.f4992OooOOO0;
                        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(o00o0o, "this$0");
                        try {
                            OooOOO oooOOO = o00o0o.f5011OooO0o;
                            if (oooOOO != null) {
                                o00o0o.f5010OooO0Oo = oooOOO.OooO0O0(o00o0o.f5013OooO0oO, o00o0o.f5007OooO00o);
                                OooOo oooOo2 = o00o0o.f5008OooO0O0;
                                Oooo0 oooo0 = o00o0o.f5012OooO0o0;
                                if (oooo0 != null) {
                                    oooOo2.OooO00o(oooo0);
                                    return;
                                } else {
                                    com.github.doyaaaaaken.kotlincsv.client.OooO.o000oOoO("observer");
                                    throw null;
                                }
                            }
                            return;
                        } catch (RemoteException unused) {
                            return;
                        }
                    default:
                        o00O0O o00o0o2 = this.f4992OooOOO0;
                        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(o00o0o2, "this$0");
                        OooOo oooOo3 = o00o0o2.f5008OooO0O0;
                        Oooo0 oooo1 = o00o0o2.f5012OooO0o0;
                        if (oooo1 == null) {
                            com.github.doyaaaaaken.kotlincsv.client.OooO.o000oOoO("observer");
                            throw null;
                        }
                        oooOo3.getClass();
                        synchronized (oooOo3.f4981OooOO0) {
                            oooOo00 = (OooOo00) oooOo3.f4981OooOO0.OooO0O0(oooo1);
                        }
                        if (oooOo00 != null) {
                            OooOOOO oooOOOO = oooOo3.f4972OooO;
                            int[] iArr = oooOo00.f4986OooO0O0;
                            if (oooOOOO.OooO0OO(Arrays.copyOf(iArr, iArr.length))) {
                                o0OOO0o o0ooo0o = oooOo3.f4973OooO00o;
                                if (o0ooo0o.OooOO0o()) {
                                    oooOo3.OooO0Oo(o0ooo0o.OooO0oO().OooooOO());
                                    return;
                                }
                                return;
                            }
                            return;
                        }
                        return;
                }
            }
        };
        final int i2 = 1;
        this.f5015OooOO0 = new Runnable(this) { // from class: androidx.room.Oooo000

            /* JADX INFO: renamed from: OooOOO0, reason: collision with root package name */
            public final /* synthetic */ o00O0O f4992OooOOO0;

            {
                this.f4992OooOOO0 = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                OooOo00 oooOo00;
                switch (i2) {
                    case 0:
                        o00O0O o00o0o = this.f4992OooOOO0;
                        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(o00o0o, "this$0");
                        try {
                            OooOOO oooOOO = o00o0o.f5011OooO0o;
                            if (oooOOO != null) {
                                o00o0o.f5010OooO0Oo = oooOOO.OooO0O0(o00o0o.f5013OooO0oO, o00o0o.f5007OooO00o);
                                OooOo oooOo2 = o00o0o.f5008OooO0O0;
                                Oooo0 oooo0 = o00o0o.f5012OooO0o0;
                                if (oooo0 != null) {
                                    oooOo2.OooO00o(oooo0);
                                    return;
                                } else {
                                    com.github.doyaaaaaken.kotlincsv.client.OooO.o000oOoO("observer");
                                    throw null;
                                }
                            }
                            return;
                        } catch (RemoteException unused) {
                            return;
                        }
                    default:
                        o00O0O o00o0o2 = this.f4992OooOOO0;
                        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(o00o0o2, "this$0");
                        OooOo oooOo3 = o00o0o2.f5008OooO0O0;
                        Oooo0 oooo1 = o00o0o2.f5012OooO0o0;
                        if (oooo1 == null) {
                            com.github.doyaaaaaken.kotlincsv.client.OooO.o000oOoO("observer");
                            throw null;
                        }
                        oooOo3.getClass();
                        synchronized (oooOo3.f4981OooOO0) {
                            oooOo00 = (OooOo00) oooOo3.f4981OooOO0.OooO0O0(oooo1);
                        }
                        if (oooOo00 != null) {
                            OooOOOO oooOOOO = oooOo3.f4972OooO;
                            int[] iArr = oooOo00.f4986OooO0O0;
                            if (oooOOOO.OooO0OO(Arrays.copyOf(iArr, iArr.length))) {
                                o0OOO0o o0ooo0o = oooOo3.f4973OooO00o;
                                if (o0ooo0o.OooOO0o()) {
                                    oooOo3.OooO0Oo(o0ooo0o.OooO0oO().OooooOO());
                                    return;
                                }
                                return;
                            }
                            return;
                        }
                        return;
                }
            }
        };
        this.f5012OooO0o0 = new Oooo0(this, (String[]) oooOo.f4976OooO0Oo.keySet().toArray(new String[0]));
        applicationContext.bindService(intent, o0oooo0, 1);
    }
}
