package com.huawei.hms.aaid.plugin;

public class ProxyCenter {
    private PushProxy proxy;

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\aaid\plugin\ProxyCenter$a.smali */
    public static class a {
        private static ProxyCenter a = new ProxyCenter();
    }

    private static ProxyCenter getInstance() {
        return a.a;
    }

    public static PushProxy getProxy() {
        return getInstance().proxy;
    }

    public static void register(PushProxy pushProxy) {
        getInstance().proxy = pushProxy;
    }
}
