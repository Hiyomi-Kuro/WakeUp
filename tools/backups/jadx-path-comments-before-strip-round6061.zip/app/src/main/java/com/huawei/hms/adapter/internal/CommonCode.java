package com.huawei.hms.adapter.internal;

public class CommonCode {
    public static final int OK = 0;
    public static final int UNBIND_SERVICE = 11;

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\adapter\internal\CommonCode$BusInterceptor.smali */
    public interface BusInterceptor {
        public static final int INDETERMINATE = 2;
        public static final int PRIVACY_AGREE = 1001;
        public static final int PRIVACY_CANCEL = 1002;
        public static final int PRIVACY_CNCEL_ERROR_CODE = 907135705;
    }

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\adapter\internal\CommonCode$MapKey.smali */
    public interface MapKey {
        public static final String API_NAME = "api_name";
        public static final String HAS_RESOLUTION = "resolution";
        public static final String HMS_FOREGROUND_RES_UI = "HMS_FOREGROUND_RES_UI";
        public static final String JSON_BODY = "json_body";
        public static final String JSON_HEADER = "json_header";
        public static final String NEW_UPDATE = "new_update";
        public static final String PRIVACY_STATEMENT_CONFIRM_RESULT = "privacy_statement_confirm_result";
        public static final String RESOLUTION_INSTALL_HMS = "installHMS";
        public static final String TRANSACTION_ID = "transaction_id";
        public static final String UPDATE_VERSION = "update_version";
    }
}
