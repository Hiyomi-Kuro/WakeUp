package com.huawei.hms.analytics;

import java.util.List;

public final class az {
    public lmn hij;
    public String ijk;
    public List<klm> klm;
    public long lmn;
    public Long ikl = 0L;
    public boolean ghi = false;

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\analytics\az$ikl.smali */
    public static class ikl {
        public Long klm;
        public Long lmn;
    }

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\analytics\az$klm.smali */
    public static class klm {
        public List<ikl> klm;
        public String lmn;
    }

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\analytics\az$lmn.smali */
    public static class lmn {
        public List<String> lmn;
    }
}
