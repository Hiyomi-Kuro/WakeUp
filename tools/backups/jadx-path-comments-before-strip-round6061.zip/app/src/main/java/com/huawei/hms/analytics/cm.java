package com.huawei.hms.analytics;

public final class cm {
    public String lmn = "1";
    public String klm = "";
    public String ikl = "";
    public String ijk = "";
    private long hij = System.currentTimeMillis();

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\analytics\cm$lmn.smali */
    public interface lmn {
        void lmn();

        void lmn(String str);
    }

    public final long lmn() {
        return System.currentTimeMillis() - this.hij;
    }
}
