package com.huawei.hms.analytics;

import com.huawei.hms.analytics.core.log.HiLog;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class dk {
    private final ThreadPoolExecutor hij;
    private static final dk lmn = new dk(1);
    private static final dk klm = new dk(3);
    private static final dk ikl = new dk(3);
    private static final dk ijk = new dk(1);

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\analytics\dk$lmn.smali */
    public static class lmn implements Runnable {
        private Runnable lmn;

        public lmn(Runnable runnable) {
            this.lmn = runnable;
        }

        @Override // java.lang.Runnable
        public final void run() {
            Runnable runnable = this.lmn;
            if (runnable != null) {
                try {
                    runnable.run();
                } catch (Throwable th) {
                    HiLog.w("ThreadStock", "InnerTask : Error has happened,From internal operations!" + th.getMessage());
                    dw.lmn(th);
                }
            }
        }
    }

    private dk(int i) {
        this.hij = new ThreadPoolExecutor(0, i, 60000L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue(5000));
    }

    public static dk ijk() {
        return ijk;
    }

    public static dk ikl() {
        return ikl;
    }

    public static dk klm() {
        return klm;
    }

    public static dk lmn() {
        return lmn;
    }

    public final void lmn(Runnable runnable) {
        try {
            this.hij.execute(new lmn(runnable));
        } catch (RejectedExecutionException unused) {
            HiLog.w("ThreadStock", "addToQueue() Exception has happened!Form rejected execution");
        }
    }
}
