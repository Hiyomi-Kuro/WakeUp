package com.huawei.hms.analytics.framework.policy;

public interface IStoragePolicy {

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\analytics\framework\policy\IStoragePolicy$PolicyType.smali */
    public enum PolicyType {
        NETWORK,
        STORAGECYCLY,
        STORAGELENGTH,
        STORAGESIZE,
        PARAMS
    }

    boolean decide(PolicyType policyType, long j);

    boolean decide(PolicyType policyType, Object obj);
}
