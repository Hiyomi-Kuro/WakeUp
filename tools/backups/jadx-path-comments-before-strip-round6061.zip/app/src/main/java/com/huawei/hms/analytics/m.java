package com.huawei.hms.analytics;

public interface m {

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\analytics\m$lmn.smali */
    public interface lmn {
        void lmn(String str, String str2, String str3);
    }
}
