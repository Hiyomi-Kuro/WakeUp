package com.huawei.hms.security;

import android.content.Context;
import android.content.Intent;

public class SecComponentInstallWizard {
    public static final String PROVIDER_NAME = "HmsCore_OpenSSL";

    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\com\huawei\hms\security\SecComponentInstallWizard$SecComponentInstallWizardListener.smali */
    public interface SecComponentInstallWizardListener {
        void onFailed(int i, Intent intent);

        void onSuccess();
    }

    public static void install(Context context) {
    }
}
