package org.threeten.bp.zone;

import com.huawei.hms.analytics.core.crypto.AesCipher;
import com.huawei.hms.framework.common.hianalytics.CrashHianalyticsData;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.Serializable;
import kotlinx.coroutines.channels.OooOo00;
import kotlinx.coroutines.o0OOO0o;
import org.threeten.bp.DayOfWeek;
import org.threeten.bp.LocalDate;
import org.threeten.bp.LocalDateTime;
import org.threeten.bp.LocalTime;
import org.threeten.bp.Month;
import org.threeten.bp.ZoneOffset;
import org.threeten.bp.chrono.IsoChronology;
import p024Oooo0o.o0000OO0;

public final class ZoneOffsetTransitionRule implements Serializable {
    private static final long serialVersionUID = 6889046316657758795L;
    private final int adjustDays;
    private final byte dom;
    private final DayOfWeek dow;
    private final Month month;
    private final ZoneOffset offsetAfter;
    private final ZoneOffset offsetBefore;
    private final ZoneOffset standardOffset;
    private final LocalTime time;
    private final TimeDefinition timeDefinition;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: loaded from: D:\Download\AndroidStudioProjects\WakeUP\smali\smali\org\threeten\bp\zone\ZoneOffsetTransitionRule$TimeDefinition.smali */
    public static final class TimeDefinition {

        /* JADX INFO: renamed from: OooOO0o, reason: collision with root package name */
        public static final /* synthetic */ TimeDefinition[] f13185OooOO0o;
        public static final TimeDefinition STANDARD;
        public static final TimeDefinition UTC;
        public static final TimeDefinition WALL;

        static {
            TimeDefinition timeDefinition = new TimeDefinition("UTC", 0);
            UTC = timeDefinition;
            TimeDefinition timeDefinition2 = new TimeDefinition("WALL", 1);
            WALL = timeDefinition2;
            TimeDefinition timeDefinition3 = new TimeDefinition("STANDARD", 2);
            STANDARD = timeDefinition3;
            f13185OooOO0o = new TimeDefinition[]{timeDefinition, timeDefinition2, timeDefinition3};
        }

        public static TimeDefinition valueOf(String str) {
            return (TimeDefinition) Enum.valueOf(TimeDefinition.class, str);
        }

        public static TimeDefinition[] values() {
            return (TimeDefinition[]) f13185OooOO0o.clone();
        }

        public LocalDateTime createDateTime(LocalDateTime localDateTime, ZoneOffset zoneOffset, ZoneOffset zoneOffset2) {
            int i = OooO0OO.f13182OooO00o[ordinal()];
            if (i != 1) {
                return i != 2 ? localDateTime : localDateTime.plusSeconds(zoneOffset2.getTotalSeconds() - zoneOffset.getTotalSeconds());
            }
            return localDateTime.plusSeconds(zoneOffset2.getTotalSeconds() - ZoneOffset.UTC.getTotalSeconds());
        }
    }

    public ZoneOffsetTransitionRule(Month month, int i, DayOfWeek dayOfWeek, LocalTime localTime, int i2, TimeDefinition timeDefinition, ZoneOffset zoneOffset, ZoneOffset zoneOffset2, ZoneOffset zoneOffset3) {
        this.month = month;
        this.dom = (byte) i;
        this.dow = dayOfWeek;
        this.time = localTime;
        this.adjustDays = i2;
        this.timeDefinition = timeDefinition;
        this.standardOffset = zoneOffset;
        this.offsetBefore = zoneOffset2;
        this.offsetAfter = zoneOffset3;
    }

    public static ZoneOffsetTransitionRule of(Month month, int i, DayOfWeek dayOfWeek, LocalTime localTime, boolean z, TimeDefinition timeDefinition, ZoneOffset zoneOffset, ZoneOffset zoneOffset2, ZoneOffset zoneOffset3) {
        o0OOO0o.OooOooO(month, "month");
        o0OOO0o.OooOooO(localTime, CrashHianalyticsData.TIME);
        o0OOO0o.OooOooO(timeDefinition, "timeDefnition");
        o0OOO0o.OooOooO(zoneOffset, "standardOffset");
        o0OOO0o.OooOooO(zoneOffset2, "offsetBefore");
        o0OOO0o.OooOooO(zoneOffset3, "offsetAfter");
        if (i < -28 || i > 31 || i == 0) {
            throw new IllegalArgumentException("Day of month indicator must be between -28 and 31 inclusive excluding zero");
        }
        if (!z || localTime.equals(LocalTime.MIDNIGHT)) {
            return new ZoneOffsetTransitionRule(month, i, dayOfWeek, localTime, z ? 1 : 0, timeDefinition, zoneOffset, zoneOffset2, zoneOffset3);
        }
        throw new IllegalArgumentException("Time must be midnight when end of day flag is true");
    }

    public static ZoneOffsetTransitionRule readExternal(DataInput dataInput) throws IOException {
        ZoneOffset zoneOffsetOfTotalSeconds;
        ZoneOffset zoneOffsetOfTotalSeconds2;
        int i = dataInput.readInt();
        Month monthOf = Month.of(i >>> 28);
        int i2 = ((264241152 & i) >>> 22) - 32;
        int i3 = (3670016 & i) >>> 19;
        DayOfWeek dayOfWeekOf = i3 == 0 ? null : DayOfWeek.of(i3);
        int i4 = (507904 & i) >>> 14;
        TimeDefinition timeDefinition = TimeDefinition.values()[(i & 12288) >>> 12];
        int i5 = (i & 4080) >>> 4;
        int i6 = (i & 12) >>> 2;
        int i7 = i & 3;
        int i8 = i4 == 31 ? dataInput.readInt() : i4 * 3600;
        ZoneOffset zoneOffsetOfTotalSeconds3 = ZoneOffset.ofTotalSeconds(i5 == 255 ? dataInput.readInt() : (i5 - 128) * 900);
        if (i6 == 3) {
            zoneOffsetOfTotalSeconds = ZoneOffset.ofTotalSeconds(dataInput.readInt());
        } else {
            zoneOffsetOfTotalSeconds = ZoneOffset.ofTotalSeconds((i6 * 1800) + zoneOffsetOfTotalSeconds3.getTotalSeconds());
        }
        ZoneOffset zoneOffset = zoneOffsetOfTotalSeconds;
        if (i7 == 3) {
            zoneOffsetOfTotalSeconds2 = ZoneOffset.ofTotalSeconds(dataInput.readInt());
        } else {
            zoneOffsetOfTotalSeconds2 = ZoneOffset.ofTotalSeconds((i7 * 1800) + zoneOffsetOfTotalSeconds3.getTotalSeconds());
        }
        if (i2 < -28 || i2 > 31 || i2 == 0) {
            throw new IllegalArgumentException("Day of month indicator must be between -28 and 31 inclusive excluding zero");
        }
        return new ZoneOffsetTransitionRule(monthOf, i2, dayOfWeekOf, LocalTime.ofSecondOfDay(o0OOO0o.OooO0oo(i8, 86400)), i8 >= 0 ? i8 / 86400 : ((i8 + 1) / 86400) - 1, timeDefinition, zoneOffsetOfTotalSeconds3, zoneOffset, zoneOffsetOfTotalSeconds2);
    }

    private Object writeReplace() {
        return new Ser((byte) 3, this);
    }

    public ZoneOffsetTransition createTransition(int i) {
        LocalDate localDateOf;
        byte b = this.dom;
        if (b < 0) {
            Month month = this.month;
            int i2 = 1;
            localDateOf = LocalDate.of(i, month, month.length(IsoChronology.INSTANCE.isLeapYear(i)) + 1 + this.dom);
            DayOfWeek dayOfWeek = this.dow;
            if (dayOfWeek != null) {
                localDateOf = localDateOf.with((o00OOOOo.OooO0OO) new o0000OO0(i2, dayOfWeek));
            }
        } else {
            localDateOf = LocalDate.of(i, this.month, b);
            DayOfWeek dayOfWeek2 = this.dow;
            if (dayOfWeek2 != null) {
                localDateOf = localDateOf.with((o00OOOOo.OooO0OO) OooOo00.OooO0oO(dayOfWeek2));
            }
        }
        return new ZoneOffsetTransition(this.timeDefinition.createDateTime(LocalDateTime.of(localDateOf.plusDays(this.adjustDays), this.time), this.standardOffset, this.offsetBefore), this.offsetBefore, this.offsetAfter);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ZoneOffsetTransitionRule)) {
            return false;
        }
        ZoneOffsetTransitionRule zoneOffsetTransitionRule = (ZoneOffsetTransitionRule) obj;
        return this.month == zoneOffsetTransitionRule.month && this.dom == zoneOffsetTransitionRule.dom && this.dow == zoneOffsetTransitionRule.dow && this.timeDefinition == zoneOffsetTransitionRule.timeDefinition && this.adjustDays == zoneOffsetTransitionRule.adjustDays && this.time.equals(zoneOffsetTransitionRule.time) && this.standardOffset.equals(zoneOffsetTransitionRule.standardOffset) && this.offsetBefore.equals(zoneOffsetTransitionRule.offsetBefore) && this.offsetAfter.equals(zoneOffsetTransitionRule.offsetAfter);
    }

    public int getDayOfMonthIndicator() {
        return this.dom;
    }

    public DayOfWeek getDayOfWeek() {
        return this.dow;
    }

    public LocalTime getLocalTime() {
        return this.time;
    }

    public Month getMonth() {
        return this.month;
    }

    public ZoneOffset getOffsetAfter() {
        return this.offsetAfter;
    }

    public ZoneOffset getOffsetBefore() {
        return this.offsetBefore;
    }

    public ZoneOffset getStandardOffset() {
        return this.standardOffset;
    }

    public TimeDefinition getTimeDefinition() {
        return this.timeDefinition;
    }

    public int hashCode() {
        int secondOfDay = ((this.time.toSecondOfDay() + this.adjustDays) << 15) + (this.month.ordinal() << 11) + ((this.dom + 32) << 5);
        DayOfWeek dayOfWeek = this.dow;
        return ((this.standardOffset.hashCode() ^ (this.timeDefinition.ordinal() + (secondOfDay + ((dayOfWeek == null ? 7 : dayOfWeek.ordinal()) << 2)))) ^ this.offsetBefore.hashCode()) ^ this.offsetAfter.hashCode();
    }

    public boolean isMidnightEndOfDay() {
        return this.adjustDays == 1 && this.time.equals(LocalTime.MIDNIGHT);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("TransitionRule[");
        sb.append(this.offsetBefore.compareTo(this.offsetAfter) > 0 ? "Gap " : "Overlap ");
        sb.append(this.offsetBefore);
        sb.append(" to ");
        sb.append(this.offsetAfter);
        sb.append(", ");
        DayOfWeek dayOfWeek = this.dow;
        if (dayOfWeek != null) {
            byte b = this.dom;
            if (b == -1) {
                sb.append(dayOfWeek.name());
                sb.append(" on or before last day of ");
                sb.append(this.month.name());
            } else if (b < 0) {
                sb.append(dayOfWeek.name());
                sb.append(" on or before last day minus ");
                sb.append((-this.dom) - 1);
                sb.append(" of ");
                sb.append(this.month.name());
            } else {
                sb.append(dayOfWeek.name());
                sb.append(" on or after ");
                sb.append(this.month.name());
                sb.append(' ');
                sb.append((int) this.dom);
            }
        } else {
            sb.append(this.month.name());
            sb.append(' ');
            sb.append((int) this.dom);
        }
        sb.append(" at ");
        if (this.adjustDays == 0) {
            sb.append(this.time);
        } else {
            long secondOfDay = (this.adjustDays * 1440) + (this.time.toSecondOfDay() / 60);
            long jOooO0oO = o0OOO0o.OooO0oO(secondOfDay, 60L);
            if (jOooO0oO < 10) {
                sb.append(0);
            }
            sb.append(jOooO0oO);
            sb.append(':');
            long jOooO = o0OOO0o.OooO(secondOfDay, 60);
            if (jOooO < 10) {
                sb.append(0);
            }
            sb.append(jOooO);
        }
        sb.append(" ");
        sb.append(this.timeDefinition);
        sb.append(", standard offset ");
        sb.append(this.standardOffset);
        sb.append(']');
        return sb.toString();
    }

    public void writeExternal(DataOutput dataOutput) {
        int hour;
        int secondOfDay = (this.adjustDays * 86400) + this.time.toSecondOfDay();
        int totalSeconds = this.standardOffset.getTotalSeconds();
        int totalSeconds2 = this.offsetBefore.getTotalSeconds() - totalSeconds;
        int totalSeconds3 = this.offsetAfter.getTotalSeconds() - totalSeconds;
        if (secondOfDay % 3600 != 0 || secondOfDay > 86400) {
            hour = 31;
        } else {
            hour = secondOfDay == 86400 ? 24 : this.time.getHour();
        }
        int i = totalSeconds % 900 == 0 ? (totalSeconds / 900) + AesCipher.AesLen.ROOTKEY_COMPONET_LEN : 255;
        int i2 = (totalSeconds2 == 0 || totalSeconds2 == 1800 || totalSeconds2 == 3600) ? totalSeconds2 / 1800 : 3;
        int i3 = (totalSeconds3 == 0 || totalSeconds3 == 1800 || totalSeconds3 == 3600) ? totalSeconds3 / 1800 : 3;
        DayOfWeek dayOfWeek = this.dow;
        dataOutput.writeInt((this.month.getValue() << 28) + ((this.dom + 32) << 22) + ((dayOfWeek == null ? 0 : dayOfWeek.getValue()) << 19) + (hour << 14) + (this.timeDefinition.ordinal() << 12) + (i << 4) + (i2 << 2) + i3);
        if (hour == 31) {
            dataOutput.writeInt(secondOfDay);
        }
        if (i == 255) {
            dataOutput.writeInt(totalSeconds);
        }
        if (i2 == 3) {
            dataOutput.writeInt(this.offsetBefore.getTotalSeconds());
        }
        if (i3 == 3) {
            dataOutput.writeInt(this.offsetAfter.getTotalSeconds());
        }
    }
}
