package o00OOO00;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.HashMap;
import org.jsoup.nodes.Entities.CoreCharset;
import org.jsoup.nodes.Entities.EscapeMode;

public abstract class OooOOO {

    /* JADX INFO: renamed from: OooO00o, reason: collision with root package name */
    public static final char[] f11889OooO00o = {',', ';'};

    /* JADX INFO: renamed from: OooO0O0, reason: collision with root package name */
    public static final HashMap f11890OooO0O0 = new HashMap();

    static {
        Entities.EscapeMode entities$EscapeMode = Entities.EscapeMode.xhtml;
        new ThreadLocal();
        Charset.forName("UTF8");
    }

    public static void OooO00o(Appendable appendable, Entities.EscapeMode entities$EscapeMode, int i) throws IOException {
        String strNameForCodepoint = entities$EscapeMode.nameForCodepoint(i);
        if ("".equals(strNameForCodepoint)) {
            appendable.append("&#x").append(Integer.toHexString(i)).append(';');
        } else {
            appendable.append('&').append(strNameForCodepoint).append(';');
        }
    }

    /* JADX WARN: Code duplicated, block: B:20:0x0045  */
    /* JADX WARN: Code duplicated, block: B:22:0x004a  */
    /* JADX WARN: Code duplicated, block: B:24:0x004e  */
    /* JADX WARN: Code duplicated, block: B:26:0x0052  */
    /* JADX WARN: Code duplicated, block: B:28:0x0056  */
    /* JADX WARN: Code duplicated, block: B:30:0x005a  */
    /* JADX WARN: Code duplicated, block: B:32:0x0064  */
    /* JADX WARN: Code duplicated, block: B:37:0x006e  */
    /* JADX WARN: Code duplicated, block: B:41:0x007a  */
    /* JADX WARN: Code duplicated, block: B:43:0x007e  */
    /* JADX WARN: Code duplicated, block: B:44:0x0084  */
    /* JADX WARN: Code duplicated, block: B:45:0x008a A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:46:0x008c  */
    /* JADX WARN: Code duplicated, block: B:47:0x0092  */
    /* JADX WARN: Code duplicated, block: B:48:0x0096  */
    /* JADX WARN: Code duplicated, block: B:53:0x00a1  */
    /* JADX WARN: Code duplicated, block: B:54:0x00a7  */
    /* JADX WARN: Code duplicated, block: B:55:0x00ad A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:56:0x00af  */
    /* JADX WARN: Code duplicated, block: B:57:0x00b5  */
    /* JADX WARN: Code duplicated, block: B:58:0x00b9  */
    /* JADX WARN: Code duplicated, block: B:60:0x00c8  */
    /* JADX WARN: Code duplicated, block: B:61:0x00cc  */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0072, code lost:
    
        r15.append(r12);
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void OooO0O0(Appendable appendable, String str, org.jsoup.nodes.OooO00o oooO00o, boolean z, boolean z2, boolean z3) throws IOException {
        String str2;
        char c;
        Entities.EscapeMode entities$EscapeMode = oooO00o.f12879OooOO0o;
        CharsetEncoder charsetEncoderOooO0O0 = (CharsetEncoder) oooO00o.f12880OooOOO.get();
        if (charsetEncoderOooO0O0 == null) {
            charsetEncoderOooO0O0 = oooO00o.OooO0O0();
        }
        Entities.CoreCharset entities$CoreCharset = oooO00o.f12882OooOOOO;
        int length = str.length();
        int iCharCount = 0;
        boolean z4 = false;
        boolean z5 = false;
        while (iCharCount < length) {
            int iCodePointAt = str.codePointAt(iCharCount);
            if (z2) {
                if (!o00OO.OooO0O0.OooO0o(iCodePointAt)) {
                    z4 = true;
                    z5 = false;
                    if (iCodePointAt < 65536) {
                        c = (char) iCodePointAt;
                        if (c != '\"') {
                            if (c != '&') {
                                appendable.append("&amp;");
                            } else if (c != '<') {
                                if (c != '>') {
                                    if (c != 160) {
                                        if ((r13 = org.jsoup.nodes.OooO0OO.f12893OooO00o[entities$CoreCharset.ordinal()]) != 1) {
                                            OooO00o(appendable, entities$EscapeMode, iCodePointAt);
                                        } else {
                                            OooO00o(appendable, entities$EscapeMode, iCodePointAt);
                                        }
                                    } else if (entities$EscapeMode != Entities.EscapeMode.xhtml) {
                                        appendable.append("&nbsp;");
                                    } else {
                                        appendable.append("&#xa0;");
                                    }
                                } else if (z) {
                                    appendable.append(c);
                                } else {
                                    appendable.append("&gt;");
                                }
                            } else if (z) {
                                appendable.append("&lt;");
                            } else {
                                appendable.append("&lt;");
                            }
                        } else if (z) {
                            appendable.append("&quot;");
                        } else {
                            appendable.append(c);
                        }
                    } else {
                        str2 = new String(Character.toChars(iCodePointAt));
                        if (charsetEncoderOooO0O0.canEncode(str2)) {
                            appendable.append(str2);
                        } else {
                            OooO00o(appendable, entities$EscapeMode, iCodePointAt);
                        }
                    }
                } else if ((!z3 || z4) && !z5) {
                    appendable.append(' ');
                    z5 = true;
                }
            } else if (iCodePointAt < 65536) {
                c = (char) iCodePointAt;
                if (c != '\"') {
                    if (c != '&') {
                        appendable.append("&amp;");
                    } else if (c != '<') {
                        if (c != '>') {
                            if (c != 160) {
                                if ((r13 = org.jsoup.nodes.OooO0OO.f12893OooO00o[entities$CoreCharset.ordinal()]) != 1) {
                                    OooO00o(appendable, entities$EscapeMode, iCodePointAt);
                                } else {
                                    OooO00o(appendable, entities$EscapeMode, iCodePointAt);
                                }
                            } else if (entities$EscapeMode != Entities.EscapeMode.xhtml) {
                                appendable.append("&nbsp;");
                            } else {
                                appendable.append("&#xa0;");
                            }
                        } else if (z) {
                            appendable.append("&gt;");
                        } else {
                            appendable.append(c);
                        }
                    } else if (z || entities$EscapeMode == Entities.EscapeMode.xhtml) {
                        appendable.append("&lt;");
                    } else {
                        appendable.append(c);
                    }
                } else if (z) {
                    appendable.append("&quot;");
                } else {
                    appendable.append(c);
                }
            } else {
                str2 = new String(Character.toChars(iCodePointAt));
                if (charsetEncoderOooO0O0.canEncode(str2)) {
                    appendable.append(str2);
                } else {
                    OooO00o(appendable, entities$EscapeMode, iCodePointAt);
                }
            }
            iCharCount += Character.charCount(iCodePointAt);
        }
    }
}
