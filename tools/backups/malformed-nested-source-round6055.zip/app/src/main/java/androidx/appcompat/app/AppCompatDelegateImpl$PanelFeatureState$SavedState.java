package androidx.appcompat.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
class AppCompatDelegateImpl.PanelFeatureState.SavedState implements Parcelable {
    public static final Parcelable.Creator<AppCompatDelegateImpl.PanelFeatureState.SavedState> CREATOR = new DecodedShadow_o00000O0();

    /* JADX INFO: renamed from: OooOO0o, reason: collision with root package name */
    public int f2047OooOO0o;

    /* JADX INFO: renamed from: OooOOO, reason: collision with root package name */
    public Bundle f2048OooOOO;

    /* JADX INFO: renamed from: OooOOO0, reason: collision with root package name */
    public boolean f2049OooOOO0;

    public static AppCompatDelegateImpl.PanelFeatureState.SavedState OooO00o(Parcel parcel, ClassLoader classLoader) {
        AppCompatDelegateImpl.PanelFeatureState.SavedState appCompatDelegateImpl$PanelFeatureState$SavedState = new AppCompatDelegateImpl.PanelFeatureState.SavedState();
        appCompatDelegateImpl$PanelFeatureState$SavedState.f2047OooOO0o = parcel.readInt();
        boolean z = parcel.readInt() == 1;
        appCompatDelegateImpl$PanelFeatureState$SavedState.f2049OooOOO0 = z;
        if (z) {
            appCompatDelegateImpl$PanelFeatureState$SavedState.f2048OooOOO = parcel.readBundle(classLoader);
        }
        return appCompatDelegateImpl$PanelFeatureState$SavedState;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f2047OooOO0o);
        parcel.writeInt(this.f2049OooOOO0 ? 1 : 0);
        if (this.f2049OooOOO0) {
            parcel.writeBundle(this.f2048OooOOO);
        }
    }
}
