package kotlin.jvm.internal;

import java.io.Serializable;

public final class Ref.CharRef implements Serializable {
    public char element;

    public String toString() {
        return String.valueOf(this.element);
    }
}
