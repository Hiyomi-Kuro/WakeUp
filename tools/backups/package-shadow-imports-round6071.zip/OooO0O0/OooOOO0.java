package OooO0O0;

import android.content.Intent;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResult;

public final class OooOOO0 extends OooO0OO.OooO {
    @Override // OooO0OO.OooO
    public final Intent OooO0oo(ComponentActivity componentActivity, Object obj) {
        Intent intent = (Intent) obj;
        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(componentActivity, "context");
        return intent;
    }

    @Override // OooO0OO.OooO
    public final Object OooOOO(int i, Intent intent) {
        return new ActivityResult(i, intent);
    }
}
