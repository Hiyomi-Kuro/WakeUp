package OooO0OO;

import android.content.Intent;
import android.view.View;
import androidx.activity.ComponentActivity;
import androidx.fragment.app.o0OO00O;
import androidx.lifecycle.o000O0O0;

public abstract class OooO {
    public static final o000O0O0 OooOO0(o0OO00O o0oo00o, kotlin.jvm.internal.OooO0O0 oooO0O0, o00O0OOO.OooO00o oooO00o, o00O0OOO.OooO00o oooO00o2, o00O0OOO.OooO00o oooO00o3) {
        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(o0oo00o, "<this>");
        return new o000O0O0(oooO0O0, oooO00o, oooO00o3, oooO00o2);
    }

    public boolean OooO0OO() {
        return false;
    }

    public abstract boolean OooO0Oo(OooOOO0.OooOO0O oooOO0O, OooOOO0.OooO0OO oooO0OO, OooOOO0.OooO0OO oooO0OO2);

    public abstract boolean OooO0o(OooOOO0.OooOO0O oooOO0O, OooOOO0.OooOO0 oooOO0, OooOOO0.OooOO0 oooOO1);

    public abstract boolean OooO0o0(OooOOO0.OooOO0O oooOO0O, Object obj, Object obj2);

    public abstract Intent OooO0oo(ComponentActivity componentActivity, Object obj);

    public com.huawei.agconnect.crash.internal.OooOO0O OooOO0O(ComponentActivity componentActivity, Object obj) {
        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(componentActivity, "context");
        return null;
    }

    public abstract View OooOO0o(int i);

    public abstract Object OooOOO(int i, Intent intent);

    public abstract boolean OooOOO0();

    public abstract void OooOOOO(OooOOO0.OooOO0 oooOO0, OooOOO0.OooOO0 oooOO1);

    public abstract void OooOOOo(OooOOO0.OooOO0 oooOO0, Thread thread);

    public abstract void OooOOo();

    public void OooOOo0() {
    }

    public abstract void OooOOoo();
}
