package com.bumptech.glide;

abstract class GeneratedAppGlideModule extends OooO0OO.OooO {
}
