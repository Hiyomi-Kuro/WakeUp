package o00000O;

import java.util.ArrayDeque;

public final class OooO0OO extends Oooo0.Oooo000 {

    /* JADX INFO: renamed from: OooOOO0, reason: collision with root package name */
    public final /* synthetic */ int f9478OooOOO0;

    public OooO0OO(int i) {
        this.f9478OooOOO0 = i;
        char[] cArr = o0000OO0.Oooo0.f9934OooO00o;
        this.f1389OooOO0o = new ArrayDeque(20);
    }

    public final OooOo00 OooO0oO() {
        switch (this.f9478OooOOO0) {
            case 0:
                return new OooO0O0(this);
            case 1:
                return new OooOO0O(this);
            default:
                return new Oooo000(this);
        }
    }
}
