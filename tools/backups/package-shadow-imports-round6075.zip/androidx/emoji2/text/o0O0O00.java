package androidx.emoji2.text;

import android.text.Spannable;

public final class o0O0O00 extends o000OOO.OooOO0 {
    @Override // o000OOO.OooOO0
    public final boolean OooOoO(Spannable spannable) {
        return Oooo0.OooOOO0.OooOo0(spannable);
    }
}
