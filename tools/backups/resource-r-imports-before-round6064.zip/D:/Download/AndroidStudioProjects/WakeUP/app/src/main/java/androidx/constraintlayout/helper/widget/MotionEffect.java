package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.constraintlayout.motion.widget.MotionHelper;
import androidx.constraintlayout.widget.R.styleable;

public class MotionEffect extends MotionHelper {

    /* JADX INFO: renamed from: OooOo, reason: collision with root package name */
    public float f3089OooOo;

    /* JADX INFO: renamed from: OooOoO, reason: collision with root package name */
    public int f3090OooOoO;

    /* JADX INFO: renamed from: OooOoO0, reason: collision with root package name */
    public int f3091OooOoO0;

    /* JADX INFO: renamed from: OooOoOO, reason: collision with root package name */
    public int f3092OooOoOO;

    /* JADX INFO: renamed from: OooOoo, reason: collision with root package name */
    public boolean f3093OooOoo;

    /* JADX INFO: renamed from: OooOoo0, reason: collision with root package name */
    public int f3094OooOoo0;

    /* JADX INFO: renamed from: OooOooO, reason: collision with root package name */
    public int f3095OooOooO;

    /* JADX INFO: renamed from: OooOooo, reason: collision with root package name */
    public int f3096OooOooo;

    public MotionEffect(Context context) {
        super(context);
        this.f3089OooOo = 0.1f;
        this.f3091OooOoO0 = 49;
        this.f3090OooOoO = 50;
        this.f3092OooOoOO = 0;
        this.f3094OooOoo0 = 0;
        this.f3093OooOoo = true;
        this.f3095OooOooO = -1;
        this.f3096OooOooo = -1;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x01d4  */
    /* JADX WARN: Code duplicated, block: B:101:0x01d7  */
    /* JADX WARN: Code duplicated, block: B:103:0x01df  */
    /* JADX WARN: Code duplicated, block: B:106:0x01ef  */
    /* JADX WARN: Code duplicated, block: B:110:0x020e  */
    /* JADX WARN: Code duplicated, block: B:111:0x0214 A[LOOP:3: B:104:0x01e9->B:111:0x0214, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:123:0x0219 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:125:0x01d0 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:126:0x01fd A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:48:0x0147  */
    /* JADX WARN: Code duplicated, block: B:92:0x01ac  */
    /* JADX WARN: Code duplicated, block: B:94:0x01bc  */
    /* JADX WARN: Code duplicated, block: B:97:0x01c6  */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x016a, code lost:
    
        if (r14 == 0.0f) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x0180, code lost:
    
        if (r14 == 0.0f) goto L60;
     */
    @Override // androidx.constraintlayout.motion.widget.MotionHelper
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void OooOOoo(androidx.constraintlayout.motion.widget.MotionLayout r20, java.util.HashMap r21) {
        /*
            Method dump skipped, instruction units count: 550
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.helper.widget.MotionEffect.OooOOoo(androidx.constraintlayout.motion.widget.MotionLayout, java.util.HashMap):void");
    }

    public final void OooOo00(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.MotionEffect);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i);
                if (index == R.styleable.MotionEffect_motionEffect_start) {
                    int i2 = typedArrayObtainStyledAttributes.getInt(index, this.f3091OooOoO0);
                    this.f3091OooOoO0 = i2;
                    this.f3091OooOoO0 = Math.max(Math.min(i2, 99), 0);
                } else if (index == R.styleable.MotionEffect_motionEffect_end) {
                    int i3 = typedArrayObtainStyledAttributes.getInt(index, this.f3090OooOoO);
                    this.f3090OooOoO = i3;
                    this.f3090OooOoO = Math.max(Math.min(i3, 99), 0);
                } else if (index == R.styleable.MotionEffect_motionEffect_translationX) {
                    this.f3092OooOoOO = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f3092OooOoOO);
                } else if (index == R.styleable.MotionEffect_motionEffect_translationY) {
                    this.f3094OooOoo0 = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f3094OooOoo0);
                } else if (index == R.styleable.MotionEffect_motionEffect_alpha) {
                    this.f3089OooOo = typedArrayObtainStyledAttributes.getFloat(index, this.f3089OooOo);
                } else if (index == R.styleable.MotionEffect_motionEffect_move) {
                    this.f3096OooOooo = typedArrayObtainStyledAttributes.getInt(index, this.f3096OooOooo);
                } else if (index == R.styleable.MotionEffect_motionEffect_strict) {
                    this.f3093OooOoo = typedArrayObtainStyledAttributes.getBoolean(index, this.f3093OooOoo);
                } else if (index == R.styleable.MotionEffect_motionEffect_viewTransition) {
                    this.f3095OooOooO = typedArrayObtainStyledAttributes.getResourceId(index, this.f3095OooOooO);
                }
            }
            int i4 = this.f3091OooOoO0;
            int i5 = this.f3090OooOoO;
            if (i4 == i5) {
                if (i4 > 0) {
                    this.f3091OooOoO0 = i4 - 1;
                } else {
                    this.f3090OooOoO = i5 + 1;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public MotionEffect(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f3089OooOo = 0.1f;
        this.f3091OooOoO0 = 49;
        this.f3090OooOoO = 50;
        this.f3092OooOoOO = 0;
        this.f3094OooOoo0 = 0;
        this.f3093OooOoo = true;
        this.f3095OooOooO = -1;
        this.f3096OooOooo = -1;
        OooOo00(context, attributeSet);
    }

    public MotionEffect(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3089OooOo = 0.1f;
        this.f3091OooOoO0 = 49;
        this.f3090OooOoO = 50;
        this.f3092OooOoOO = 0;
        this.f3094OooOoo0 = 0;
        this.f3093OooOoo = true;
        this.f3095OooOooO = -1;
        this.f3096OooOooo = -1;
        OooOo00(context, attributeSet);
    }
}
