package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.RectF;
import android.util.Xml;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.R.styleable;

public final class OooO0o {

    /* JADX INFO: renamed from: OooOooo, reason: collision with root package name */
    public static final float[][] f3191OooOooo = {new float[]{0.5f, 0.0f}, new float[]{0.0f, 0.5f}, new float[]{1.0f, 0.5f}, new float[]{0.5f, 1.0f}, new float[]{0.5f, 0.5f}, new float[]{0.0f, 0.5f}, new float[]{1.0f, 0.5f}};

    /* JADX INFO: renamed from: Oooo000, reason: collision with root package name */
    public static final float[][] f3192Oooo000 = {new float[]{0.0f, -1.0f}, new float[]{0.0f, 1.0f}, new float[]{-1.0f, 0.0f}, new float[]{1.0f, 0.0f}, new float[]{-1.0f, 0.0f}, new float[]{1.0f, 0.0f}};

    /* JADX INFO: renamed from: OooO, reason: collision with root package name */
    public final int f3193OooO;

    /* JADX INFO: renamed from: OooO00o, reason: collision with root package name */
    public final int f3194OooO00o;

    /* JADX INFO: renamed from: OooO0O0, reason: collision with root package name */
    public final int f3195OooO0O0;

    /* JADX INFO: renamed from: OooO0OO, reason: collision with root package name */
    public int f3196OooO0OO;

    /* JADX INFO: renamed from: OooO0Oo, reason: collision with root package name */
    public final int f3197OooO0Oo;

    /* JADX INFO: renamed from: OooO0o, reason: collision with root package name */
    public final int f3198OooO0o;

    /* JADX INFO: renamed from: OooO0o0, reason: collision with root package name */
    public final int f3199OooO0o0;

    /* JADX INFO: renamed from: OooO0oO, reason: collision with root package name */
    public float f3200OooO0oO;

    /* JADX INFO: renamed from: OooO0oo, reason: collision with root package name */
    public float f3201OooO0oo;

    /* JADX INFO: renamed from: OooOO0, reason: collision with root package name */
    public final boolean f3202OooOO0;

    /* JADX INFO: renamed from: OooOO0O, reason: collision with root package name */
    public float f3203OooOO0O;

    /* JADX INFO: renamed from: OooOO0o, reason: collision with root package name */
    public float f3204OooOO0o;

    /* JADX INFO: renamed from: OooOOOo, reason: collision with root package name */
    public float f3208OooOOOo;

    /* JADX INFO: renamed from: OooOOo, reason: collision with root package name */
    public final MotionLayout f3209OooOOo;

    /* JADX INFO: renamed from: OooOOo0, reason: collision with root package name */
    public float f3210OooOOo0;

    /* JADX INFO: renamed from: OooOOoo, reason: collision with root package name */
    public final float f3211OooOOoo;

    /* JADX INFO: renamed from: OooOo, reason: collision with root package name */
    public final float f3212OooOo;

    /* JADX INFO: renamed from: OooOo0, reason: collision with root package name */
    public final boolean f3213OooOo0;

    /* JADX INFO: renamed from: OooOo00, reason: collision with root package name */
    public final float f3214OooOo00;

    /* JADX INFO: renamed from: OooOo0O, reason: collision with root package name */
    public final float f3215OooOo0O;

    /* JADX INFO: renamed from: OooOo0o, reason: collision with root package name */
    public final int f3216OooOo0o;

    /* JADX INFO: renamed from: OooOoO, reason: collision with root package name */
    public final float f3217OooOoO;

    /* JADX INFO: renamed from: OooOoO0, reason: collision with root package name */
    public final float f3218OooOoO0;

    /* JADX INFO: renamed from: OooOoOO, reason: collision with root package name */
    public final float f3219OooOoOO;

    /* JADX INFO: renamed from: OooOoo, reason: collision with root package name */
    public final int f3220OooOoo;

    /* JADX INFO: renamed from: OooOoo0, reason: collision with root package name */
    public final float f3221OooOoo0;

    /* JADX INFO: renamed from: OooOooO, reason: collision with root package name */
    public final int f3222OooOooO;

    /* JADX INFO: renamed from: OooOOO0, reason: collision with root package name */
    public boolean f3206OooOOO0 = false;

    /* JADX INFO: renamed from: OooOOO, reason: collision with root package name */
    public final float[] f3205OooOOO = new float[2];

    /* JADX INFO: renamed from: OooOOOO, reason: collision with root package name */
    public final int[] f3207OooOOOO = new int[2];

    public OooO0o(Context context, MotionLayout motionLayout, XmlResourceParser xmlResourceParser) {
        this.f3194OooO00o = 0;
        this.f3195OooO0O0 = 0;
        this.f3196OooO0OO = 0;
        this.f3197OooO0Oo = -1;
        this.f3199OooO0o0 = -1;
        this.f3198OooO0o = -1;
        this.f3200OooO0oO = 0.5f;
        this.f3201OooO0oo = 0.5f;
        this.f3193OooO = -1;
        this.f3202OooOO0 = false;
        this.f3203OooOO0O = 0.0f;
        this.f3204OooOO0o = 1.0f;
        this.f3211OooOOoo = 4.0f;
        this.f3214OooOo00 = 1.2f;
        this.f3213OooOo0 = true;
        this.f3215OooOo0O = 1.0f;
        this.f3216OooOo0o = 0;
        this.f3212OooOo = 10.0f;
        this.f3218OooOoO0 = 10.0f;
        this.f3217OooOoO = 1.0f;
        this.f3219OooOoOO = Float.NaN;
        this.f3221OooOoo0 = Float.NaN;
        this.f3220OooOoo = 0;
        this.f3222OooOooO = 0;
        this.f3209OooOOo = motionLayout;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlResourceParser), R.styleable.OnSwipe);
        int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
        for (int i = 0; i < indexCount; i++) {
            int index = typedArrayObtainStyledAttributes.getIndex(i);
            if (index == R.styleable.OnSwipe_touchAnchorId) {
                this.f3197OooO0Oo = typedArrayObtainStyledAttributes.getResourceId(index, this.f3197OooO0Oo);
            } else if (index == R.styleable.OnSwipe_touchAnchorSide) {
                int i2 = typedArrayObtainStyledAttributes.getInt(index, this.f3194OooO00o);
                this.f3194OooO00o = i2;
                float[] fArr = f3191OooOooo[i2];
                this.f3201OooO0oo = fArr[0];
                this.f3200OooO0oO = fArr[1];
            } else if (index == R.styleable.OnSwipe_dragDirection) {
                int i3 = typedArrayObtainStyledAttributes.getInt(index, this.f3195OooO0O0);
                this.f3195OooO0O0 = i3;
                if (i3 < 6) {
                    float[] fArr2 = f3192Oooo000[i3];
                    this.f3203OooOO0O = fArr2[0];
                    this.f3204OooOO0o = fArr2[1];
                } else {
                    this.f3204OooOO0o = Float.NaN;
                    this.f3203OooOO0O = Float.NaN;
                    this.f3202OooOO0 = true;
                }
            } else if (index == R.styleable.OnSwipe_maxVelocity) {
                this.f3211OooOOoo = typedArrayObtainStyledAttributes.getFloat(index, this.f3211OooOOoo);
            } else if (index == R.styleable.OnSwipe_maxAcceleration) {
                this.f3214OooOo00 = typedArrayObtainStyledAttributes.getFloat(index, this.f3214OooOo00);
            } else if (index == R.styleable.OnSwipe_moveWhenScrollAtTop) {
                this.f3213OooOo0 = typedArrayObtainStyledAttributes.getBoolean(index, this.f3213OooOo0);
            } else if (index == R.styleable.OnSwipe_dragScale) {
                this.f3215OooOo0O = typedArrayObtainStyledAttributes.getFloat(index, this.f3215OooOo0O);
            } else if (index == R.styleable.OnSwipe_dragThreshold) {
                this.f3212OooOo = typedArrayObtainStyledAttributes.getFloat(index, this.f3212OooOo);
            } else if (index == R.styleable.OnSwipe_touchRegionId) {
                this.f3199OooO0o0 = typedArrayObtainStyledAttributes.getResourceId(index, this.f3199OooO0o0);
            } else if (index == R.styleable.OnSwipe_onTouchUp) {
                this.f3196OooO0OO = typedArrayObtainStyledAttributes.getInt(index, this.f3196OooO0OO);
            } else if (index == R.styleable.OnSwipe_nestedScrollFlags) {
                this.f3216OooOo0o = typedArrayObtainStyledAttributes.getInteger(index, 0);
            } else if (index == R.styleable.OnSwipe_limitBoundsTo) {
                this.f3198OooO0o = typedArrayObtainStyledAttributes.getResourceId(index, 0);
            } else if (index == R.styleable.OnSwipe_rotationCenterId) {
                this.f3193OooO = typedArrayObtainStyledAttributes.getResourceId(index, this.f3193OooO);
            } else if (index == R.styleable.OnSwipe_springDamping) {
                this.f3218OooOoO0 = typedArrayObtainStyledAttributes.getFloat(index, this.f3218OooOoO0);
            } else if (index == R.styleable.OnSwipe_springMass) {
                this.f3217OooOoO = typedArrayObtainStyledAttributes.getFloat(index, this.f3217OooOoO);
            } else if (index == R.styleable.OnSwipe_springStiffness) {
                this.f3219OooOoOO = typedArrayObtainStyledAttributes.getFloat(index, this.f3219OooOoOO);
            } else if (index == R.styleable.OnSwipe_springStopThreshold) {
                this.f3221OooOoo0 = typedArrayObtainStyledAttributes.getFloat(index, this.f3221OooOoo0);
            } else if (index == R.styleable.OnSwipe_springBoundary) {
                this.f3220OooOoo = typedArrayObtainStyledAttributes.getInt(index, this.f3220OooOoo);
            } else if (index == R.styleable.OnSwipe_autoCompleteMode) {
                this.f3222OooOooO = typedArrayObtainStyledAttributes.getInt(index, this.f3222OooOooO);
            }
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    public final RectF OooO00o(MotionLayout motionLayout, RectF rectF) {
        View viewFindViewById;
        int i = this.f3198OooO0o;
        if (i == -1 || (viewFindViewById = motionLayout.findViewById(i)) == null) {
            return null;
        }
        rectF.set(viewFindViewById.getLeft(), viewFindViewById.getTop(), viewFindViewById.getRight(), viewFindViewById.getBottom());
        return rectF;
    }

    public final RectF OooO0O0(ViewGroup viewGroup, RectF rectF) {
        View viewFindViewById;
        int i = this.f3199OooO0o0;
        if (i == -1 || (viewFindViewById = viewGroup.findViewById(i)) == null) {
            return null;
        }
        rectF.set(viewFindViewById.getLeft(), viewFindViewById.getTop(), viewFindViewById.getRight(), viewFindViewById.getBottom());
        return rectF;
    }

    public final void OooO0OO(boolean z) {
        float[][] fArr = f3191OooOooo;
        float[][] fArr2 = f3192Oooo000;
        if (z) {
            fArr2[4] = fArr2[3];
            fArr2[5] = fArr2[2];
            fArr[5] = fArr[2];
            fArr[6] = fArr[1];
        } else {
            fArr2[4] = fArr2[2];
            fArr2[5] = fArr2[3];
            fArr[5] = fArr[1];
            fArr[6] = fArr[2];
        }
        float[] fArr3 = fArr[this.f3194OooO00o];
        this.f3201OooO0oo = fArr3[0];
        this.f3200OooO0oO = fArr3[1];
        int i = this.f3195OooO0O0;
        if (i >= 6) {
            return;
        }
        float[] fArr4 = fArr2[i];
        this.f3203OooOO0O = fArr4[0];
        this.f3204OooOO0o = fArr4[1];
    }

    public final String toString() {
        if (Float.isNaN(this.f3203OooOO0O)) {
            return "rotation";
        }
        return this.f3203OooOO0O + " , " + this.f3204OooOO0o;
    }
}
