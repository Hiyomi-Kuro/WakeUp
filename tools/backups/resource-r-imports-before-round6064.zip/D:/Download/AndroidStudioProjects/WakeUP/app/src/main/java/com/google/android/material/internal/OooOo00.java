package com.google.android.material.internal;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.R.layout;

public final class OooOo00 extends oo000o {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public OooOo00(int i, LayoutInflater layoutInflater, RecyclerView recyclerView) {
        super(layoutInflater.inflate(R.layout.design_navigation_item_separator, (ViewGroup) recyclerView, false));
        if (i != 2) {
        } else {
            super(layoutInflater.inflate(R.layout.design_navigation_item_subheader, (ViewGroup) recyclerView, false));
        }
    }
}
