package p024Oooo0o;

import android.view.Window;

public final class o0O00oO0 extends o0O00o00 {
    @Override // o000OOO.OooOO0
    public final void Oooo00O(boolean z) {
        if (!z) {
            Oooo(16);
            return;
        }
        Window window = this.f1564OooOOO0;
        window.clearFlags(134217728);
        window.addFlags(Integer.MIN_VALUE);
        Oooo0oo(16);
    }
}
