package com.kaori.wakeupschedule.schedule;

public final /* synthetic */ class OooOo {

    /* JADX INFO: renamed from: OooO00o, reason: collision with root package name */
    public final /* synthetic */ ScheduleActivity f8226OooO00o;
}
