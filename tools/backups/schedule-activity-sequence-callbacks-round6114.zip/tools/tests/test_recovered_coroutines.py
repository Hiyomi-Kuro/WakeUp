"""Static regression tests that compare recovered Java with source Smali.

These checks are intentionally not represented as Android runtime tests. The
project-wide javac failure currently prevents Gradle unit-test execution.
"""

from __future__ import annotations

import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
JAVA = ROOT / "app/src/main/java"
SMALI = ROOT / "smali/smali"


def java_method(source: str, pattern: str) -> str:
    match = re.search(pattern, source, re.MULTILINE)
    if not match:
        raise AssertionError(f"Java method not found: {pattern}")
    opening = source.find("{", match.start(), match.end())
    depth = 0
    state = "code"
    escaped = False
    i = opening
    while i < len(source):
        ch = source[i]
        nxt = source[i + 1] if i + 1 < len(source) else ""
        if state == "line":
            if ch == "\n":
                state = "code"
        elif state == "block":
            if ch == "*" and nxt == "/":
                state = "code"
                i += 1
        elif state in ("string", "char"):
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif (state == "string" and ch == '"') or (state == "char" and ch == "'"):
                state = "code"
        else:
            if ch == "/" and nxt == "/":
                state = "line"
                i += 1
            elif ch == "/" and nxt == "*":
                state = "block"
                i += 1
            elif ch == '"':
                state = "string"
            elif ch == "'":
                state = "char"
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return source[match.start() : i + 1]
        i += 1
    raise AssertionError(f"Unclosed Java method: {pattern}")


def smali_method(path: Path, signature: str) -> str:
    source = path.read_text(encoding="utf-8")
    start = source.find(signature)
    if start < 0:
        raise AssertionError(f"Smali method not found: {signature}")
    end = source.find(".end method", start)
    if end < 0:
        raise AssertionError(f"Smali method has no end marker: {signature}")
    return source[start : end + len(".end method")]


class RecoveredCoroutineTests(unittest.TestCase):
    def test_login_import_state_machine_is_present_and_not_a_placeholder(self) -> None:
        java = (JAVA / "com/kaori/wakeupschedule/schedule_import/LoginWebFragment.java").read_text(encoding="utf-8")
        method = java_method(java, r"public final Object OoooOOO\(OooO0o continuation\)\s*\{")
        original = smali_method(
            SMALI / "com/suda/yzune/wakeupschedule/schedule_import/LoginWebFragment.smali",
            ".method public final OoooOOO(Lkotlin/coroutines/OooO0o;)Ljava/lang/Object;",
        )

        states = {int(n) for n in re.findall(r"\bcase\s+(\d+)\s*:", method)}
        self.assertGreaterEqual(len(states), 29)
        self.assertIn(28, states)
        self.assertNotIn("UnsupportedOperationException", method)
        self.assertIn("LoginWebFragment$login$1", method)
        self.assertIn("packed-switch", original)
        self.assertGreaterEqual(len(re.findall(r"^\s*:pswitch_", original, re.MULTILINE)), 29)
        self.assertIn("showRecoveredLoginConnectionError()", method)

    def test_schedule_migration_matches_smali_data_and_side_effects(self) -> None:
        java = (JAVA / "com/kaori/wakeupschedule/settings/ModifyScheduleToolActivity$save$1.java").read_text(encoding="utf-8")
        method = java_method(java, r"public final (?:java\.lang\.)?Object invokeSuspend\((?:java\.lang\.)?Object \w+\)\s*\{")
        original = smali_method(
            SMALI / "com/suda/yzune/wakeupschedule/settings/ModifyScheduleToolActivity$save$1.smali",
            ".method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;",
        )

        getters = (
            "getId()", "getDay()", "getRoom()", "getTeacher()", "getStartNode()",
            "getStep()", "getStartWeek()", "getEndWeek()", "getType()",
            "getTableId()", "getLevel()", "getOwnTime()", "getStartTime()", "getEndTime()",
        )
        positions = [method.index(f"course.{getter}") for getter in getters]
        self.assertEqual(positions, sorted(positions))
        for getter in getters:
            self.assertIn(f"->%s" % getter, original)

        for assignment in (
            "detail.setStartWeek(toWeek)",
            "detail.setEndWeek(toWeek)",
            "detail.setType(0)",
            "detail.setDay(toDay)",
        ):
            self.assertIn(assignment, method)
        self.assertIn("Landroidx/room/OooO0O0;->OooO0Oo", original)
        self.assertIn("dao.OooO0Oo(detail, this)", method)
        self.assertIn("OooO0OO.OooOoOO(manager, activity)", method)
        self.assertIn("调课成功", method)
        self.assertIn("catch (Exception", method)
        self.assertIn("error_with_exception", method)

    def test_shared_flow_collect_state_machine_releases_slot_on_failure(self) -> None:
        java = (JAVA / "kotlinx/coroutines/flow/o000oOoO.java").read_text(encoding="utf-8")
        method = java_method(
            java,
            r"public static kotlin\.coroutines\.intrinsics\.CoroutineSingletons OooO0oo\(",
        )
        original = smali_method(
            SMALI / "kotlinx/coroutines/flow/o000oOoO.smali",
            ".method public static OooO0oo(Lkotlinx/coroutines/flow/o000oOoO;Lkotlinx/coroutines/flow/OooOO0O;Lkotlin/coroutines/OooO0o;)Lkotlin/coroutines/intrinsics/CoroutineSingletons;",
        )

        self.assertNotIn("UnsupportedOperationException", method)
        self.assertIn("state.label = 2", method)  # waiting for a shared value
        self.assertIn("state.label = 3", method)  # emitting to the collector
        self.assertIn("flow.OooO0o(slot, state)", method)
        self.assertIn("value == kotlinx.coroutines.flow.OooOOO0.f9146OooO00o", method)
        self.assertIn("collector.emit(value, state)", method)
        self.assertIn("flow.OooO0o0(slot)", method)
        self.assertIn(
            "->OooO0o(Lkotlinx/coroutines/flow/o0OoOo0;Lkotlin/coroutines/OooO0o;)Ljava/lang/Object;",
            original,
        )
        self.assertIn("->emit(Ljava/lang/Object;Lkotlin/coroutines/OooO0o;)Ljava/lang/Object;", original)
        self.assertIn("OooO0o0(Lkotlinx/coroutines/flow/internal/OooO0OO;)V", original)

    def test_work_data_deserializer_matches_smali_format_and_limit(self) -> None:
        java = (JAVA / "androidx/work/OooO.java").read_text(encoding="utf-8")
        method = java_method(java, r"public static androidx\.work\.OooO OooO00o\(byte\[\] serialized\)\s*\{")
        original = smali_method(SMALI / "androidx/work/OooO.smali", ".method public static OooO00o([B)Landroidx/work/OooO;")

        self.assertNotIn("Method not decompiled", method)
        self.assertIn("serialized.length > 10240", method)
        self.assertIn("objectStream.readInt()", method)
        self.assertIn("objectStream.readUTF()", method)
        self.assertIn("objectStream.readObject()", method)
        self.assertIn("new androidx.work.OooO(values)", method)
        for instruction in ("readInt()I", "readUTF()Ljava/lang/String;", "readObject()Ljava/lang/Object;", "0x2800"):
            self.assertIn(instruction, original)

    def test_suspend_lambda_accepts_wildcard_completion_types(self) -> None:
        java = (JAVA / "kotlin/coroutines/jvm/internal/SuspendLambda.java").read_text(encoding="utf-8")
        original = smali_method(
            SMALI / "kotlin/coroutines/jvm/internal/SuspendLambda.smali",
            ".method public constructor <init>(ILkotlin/coroutines/OooO0o;)V",
        )

        self.assertIn("SuspendLambda(int i, OooO0o<?> oooO0o)", java)
        self.assertIn("super((OooO0o<Object>) oooO0o)", java)
        self.assertIn("<init>(ILkotlin/coroutines/OooO0o;)V", original)
        self.assertIn('"Ljava/lang/Object;"', original)

    def test_continuation_impl_accepts_wildcard_completion_types(self) -> None:
        java = (JAVA / "kotlin/coroutines/jvm/internal/ContinuationImpl.java").read_text(encoding="utf-8")
        one_arg = smali_method(
            SMALI / "kotlin/coroutines/jvm/internal/ContinuationImpl.smali",
            ".method public constructor <init>(Lkotlin/coroutines/OooO0o;)V",
        )
        with_context = smali_method(
            SMALI / "kotlin/coroutines/jvm/internal/ContinuationImpl.smali",
            ".method public constructor <init>(Lkotlin/coroutines/OooO0o;Lkotlin/coroutines/OooOOOO;)V",
        )

        self.assertIn("ContinuationImpl(OooO0o<?> oooO0o)", java)
        self.assertIn("ContinuationImpl(OooO0o<?> oooO0o, OooOOOO oooOOOO)", java)
        self.assertIn("super((OooO0o<Object>) oooO0o)", java)
        self.assertIn("<init>(Lkotlin/coroutines/OooO0o;)V", one_arg)
        self.assertIn("<init>(Lkotlin/coroutines/OooO0o;Lkotlin/coroutines/OooOOOO;)V", with_context)

    def test_restricted_suspend_lambda_accepts_wildcard_completion_types(self) -> None:
        java = (JAVA / "kotlin/coroutines/jvm/internal/RestrictedSuspendLambda.java").read_text(encoding="utf-8")
        original = smali_method(
            SMALI / "kotlin/coroutines/jvm/internal/RestrictedSuspendLambda.smali",
            ".method public constructor <init>(ILkotlin/coroutines/OooO0o;)V",
        )

        self.assertIn("RestrictedSuspendLambda(int i, OooO0o<?> oooO0o)", java)
        self.assertIn("super((OooO0o<Object>) oooO0o)", java)
        self.assertIn("<init>(ILkotlin/coroutines/OooO0o;)V", original)
        self.assertIn('"Ljava/lang/Object;"', original)

    def test_glide_permission_checker_matches_smali_api_branches(self) -> None:
        java = (JAVA / "com/bumptech/glide/OooO0o.java").read_text(encoding="utf-8")
        method = java_method(java, r"public static int OooO0oO\(android\.content\.Context context, java\.lang\.String permission\)\s*\{")
        original = smali_method(
            SMALI / "com/bumptech/glide/OooO0o.smali",
            ".method public static OooO0oO(Landroid/content/Context;Ljava/lang/String;)I",
        )

        self.assertNotIn("Method not decompiled", method)
        self.assertIn("context.checkPermission(permission, processId, processUid)", method)
        self.assertIn("permission = sdk >= 23", method)
        self.assertIn("if (sdk >= 29)", method)
        self.assertIn("android.os.Binder.getCallingUid()", method)
        self.assertIn("return result;", method)
        for invocation in ("Context;->checkPermission", "OooO0Oo(Ljava/lang/String;)Ljava/lang/String;", "o0000Ooo;->OooO00o", "Binder;->getCallingUid"):
            self.assertIn(invocation, original)

    def test_activity_back_callbacks_match_original_functional_interfaces(self) -> None:
        java = (JAVA / "androidx/activity/o0ooOOo.java").read_text(encoding="utf-8")
        self.assertNotRegex(java, r"super\([01]\);")
        self.assertEqual(java.count("new o00O0OOO.OooOo()"), 2)
        self.assertEqual(java.count("new o00O0OOO.OooO00o()"), 3)
        for suffix, interface in (
            (1, "Lo00O0OOO/OooOo;"),
            (2, "Lo00O0OOO/OooOo;"),
            (3, "Lo00O0OOO/OooO00o;"),
            (4, "Lo00O0OOO/OooO00o;"),
            (5, "Lo00O0OOO/OooO00o;"),
        ):
            raw = (SMALI / f"androidx/activity/OnBackPressedDispatcher${suffix}.smali").read_text(encoding="utf-8")
            self.assertIn(".super Lkotlin/jvm/internal/Lambda;", raw)
            self.assertIn(f".implements {interface}", raw)

    def test_interface_callbacks_keep_smali_outer_captures(self) -> None:
        fragment = (JAVA / "androidx/fragment/app/o0000O0O.java").read_text(encoding="utf-8")
        fragment_smali = (SMALI / "androidx/fragment/app/o00000.smali").read_text(encoding="utf-8")
        callback = (JAVA / "androidx/fragment/app/o00000.java").read_text(encoding="utf-8")
        self.assertEqual(fragment.count("new o00000(this, "), 4)
        self.assertIn("implements p025Oooo0o0.OooOo00", callback)
        self.assertIn("public final int OooO00o;", callback)
        self.assertIn("public final o0000O0O OooO0O0;", callback)
        self.assertIn(".implements LOooo0o0/OooOo00;", fragment_smali)
        self.assertIn("<init>(Landroidx/fragment/app/o0000O0O;I)V", fragment_smali)
        for value, method in ((0, "OooO0oo(false, configuration)"), (1, "multiWindowMode.intValue() == 80"),
                              (2, "OooOOO(state.f1252OooO00o, false)"),
                              (3, "OooOOoo(stateChange.f1262OooO00o, false)")):
            self.assertIn(f"new o00000(this, {value})", fragment)
            self.assertIn(method, callback)

        room = (JAVA / "androidx/room/o00O0O.java").read_text(encoding="utf-8")
        room_smali = (SMALI / "androidx/room/Oooo000.smali").read_text(encoding="utf-8")
        self.assertEqual(room.count("new Runnable()"), 2)
        self.assertEqual(room.count("this.f4992OooOOO0 = o00O0O.this;"), 2)
        self.assertIn(".implements Ljava/lang/Runnable;", room_smali)
        self.assertIn("<init>(Landroidx/room/o00O0O;I)V", room_smali)

    def test_emoji_callback_and_saved_state_inner_class_match_smali(self) -> None:
        emoji = (JAVA / "androidx/emoji2/text/oo000o.java").read_text(encoding="utf-8")
        emoji_interface = (JAVA / "androidx/emoji2/text/OooOo00.java").read_text(encoding="utf-8")
        emoji_smali = (SMALI / "androidx/emoji2/text/oo000o.smali").read_text(encoding="utf-8")
        self.assertNotIn("import OooO0OO.OooOo00;", emoji)
        self.assertRegex(emoji_interface, r"public\s+interface\s+OooOo00\b")
        self.assertIn(".implements Landroidx/emoji2/text/OooOo00;", emoji_smali)

        saved_state = (JAVA / "androidx/customview/view/AbsSavedState.java").read_text(encoding="utf-8")
        inner_smali = (SMALI / "androidx/customview/view/AbsSavedState$1.smali").read_text(encoding="utf-8")
        self.assertIn("public static class AnonymousClass1 extends AbsSavedState", saved_state)
        self.assertNotIn("this$0", inner_smali)
        self.assertNotIn("OooOO0o:Landroidx/customview/view/AbsSavedState;", inner_smali)

    def test_zhengfang_parser_preserves_smali_fallback_order(self) -> None:
        java = (JAVA / "com/kaori/wakeupschedule/schedule_parser/parser/zf/OooO0O0.java").read_text(encoding="utf-8")
        original = smali_method(
            SMALI / "com/suda/yzune/wakeupschedule/schedule_parser/parser/zf/OooO0O0.smali",
            ".method public final OooO0Oo(Lkotlin/coroutines/OooO0o;)Ljava/lang/Object;",
        )

        parser_factory = java_method(java, r"private OooOOO0 parserFor\(int index\)\s*\{")
        parser_variants = (
            "new o000O00O(this.f11236OooO00o, 27)",
            "new o000O00O(this.f11236OooO00o, 26)",
            "new o000O00O(this.f11236OooO00o, 28)",
            "new OooO0OO(this.f11236OooO00o, 0)",
            "new OooO0OO(this.f11236OooO00o, 1)",
            "new OooOo(this.f11236OooO00o, 3)",
        )
        positions = [parser_factory.index(variant) for variant in parser_variants]
        self.assertEqual(positions, sorted(positions))
        for parser_index in (27, 26, 28):
            self.assertRegex(original, rf"const/16 v\d+, 0x{parser_index:x}")
        for getter in ("getDay()", "getStartNode()", "getEndNode()", "getStartWeek()", "getEndWeek()"):
            self.assertIn(f"->{getter}", original)
            self.assertIn(f"course.{getter} < 1", java)
        self.assertIn("CoroutineSingletons.COROUTINE_SUSPENDED", java)
        self.assertIn('"新正方："', java)
        self.assertIn('"班级正方："', java)
        self.assertNotIn("course4.getDay()", java)

    def test_schedule_import_course_merging_matches_smali_defaults(self) -> None:
        java = (JAVA / "com/kaori/wakeupschedule/schedule_import/o00O0O.java").read_text(encoding="utf-8")
        course = (JAVA / "com/kaori/wakeupschedule/schedule_parser/bean/base/Course.java").read_text(encoding="utf-8")
        original = smali_method(
            SMALI / "com/suda/yzune/wakeupschedule/schedule_import/o00O0O.smali",
            ".method public final OooO0oo(Landroid/app/Application;ILkotlin/coroutines/OooO0o;)Ljava/lang/Object;",
        )

        self.assertNotIn("6646 &", java)
        self.assertIn("course.getName(), course.getDay(), course.getRoom(), course.getTeacher(), 0, 0", java)
        self.assertIn("numArr3[0].intValue(), numArr3[1].intValue()", java)
        self.assertIn("course2.getStartWeek()", java)
        self.assertEqual(original.count("->copy$default("), 2)
        self.assertEqual(original.count("const/16 v25, 0x1fcf"), 2)
        for getter in ("getName()", "getDay()", "getRoom()", "getTeacher()", "getStartWeek()", "getEndWeek()",
                       "getType()", "getCredit()", "getNote()", "getStartTime()", "getEndTime()"):
            self.assertIn(getter, course)

    def test_material_datepicker_platform_bridges_match_smali(self) -> None:
        java = (JAVA / "com/google/android/material/datepicker/o0000.java").read_text(encoding="utf-8")
        original = (SMALI / "com/google/android/material/datepicker/o0000.smali").read_text(encoding="utf-8")
        methods = re.findall(r"(?m)^\.method public static bridge synthetic (\w+)\(", original)

        self.assertEqual(len(methods), 30)
        self.assertEqual(len(set(methods)), 30)
        for method in methods:
            self.assertRegex(java, rf"\b{re.escape(method)}\s*\(")
        for body in (
            "return function.apply(first, second);",
            "return function.apply(value);",
            "return Comparator.comparing((Function) function, comparator);",
            "list.removeIf(predicate);",
            "optional.ifPresent(consumer);",
            "context.moveSharedPreferencesFrom(sourceContext, name);",
        ):
            self.assertIn(body, java)

    def test_thu_parser_reconstruction_matches_smali_defaults_and_ranges(self) -> None:
        java = (JAVA / "com/kaori/wakeupschedule/schedule_parser/parser/o000O00.java").read_text(encoding="utf-8")
        range_java = (JAVA / "p115o00O0Oo/OooO0o.java").read_text(encoding="utf-8")
        original = smali_method(
            SMALI / "com/suda/yzune/wakeupschedule/schedule_parser/parser/o000O00.smali",
            ".method public final OooO0Oo(Lkotlin/coroutines/OooO0o;)Ljava/lang/Object;",
        )

        self.assertNotIn(", r7)", java)
        self.assertNotIn("while (r5.hasNext())", java)
        self.assertIn("Iterator it3 = codex.recovery.KotlinRegexCompat.findAll", java)
        self.assertIn("for (String str15 : listO0ooOO6)", java)
        self.assertIn("weekBean.getStart(), weekBean.getEnd(), weekBean.getType()", java)
        self.assertIn("0x1e3f", original)
        self.assertIn("WeekBean;->getStart()I", original)
        self.assertIn("WeekBean;->getEnd()I", original)
        self.assertIn("WeekBean;->getType()I", original)
        self.assertIn("public OooO0o(int first, int last, int step)", range_java)
        self.assertIn("Iterable listOooOo;", java)
        self.assertNotIn("List listOooOo;", java)
        self.assertIn("invoke-direct {v5, v6, v3, v7}, Lo00O0Oo/OooO0O0;-><init>(III)V", original)
        self.assertIn("throw v11", original)

    def test_component_activity_types_and_lambda_owner_match_smali(self) -> None:
        java = (JAVA / "androidx/activity/ComponentActivity.java").read_text(encoding="utf-8")
        lambda_java = (JAVA / "androidx/activity/OooO.java").read_text(encoding="utf-8")
        activity_smali = (SMALI / "androidx/activity/ComponentActivity.smali").read_text(encoding="utf-8")
        lambda_smali = smali_method(
            SMALI / "androidx/activity/OooO.smali",
            ".method public final invoke()Ljava/lang/Object;",
        )
        package_class = (JAVA / "OooO00o/OooO00o.java").read_text(encoding="utf-8")
        package_smali = (SMALI / "OooO00o/OooO00o.smali").read_text(encoding="utf-8")

        self.assertIn("p042OooooOo.o00O0OOO", java)
        self.assertIn(".implements LOooooOo/o00O0OOO;", activity_smali)
        self.assertIn("OooO00o.OooO00o", java)
        self.assertIn("package OooO00o;", package_class)
        self.assertIn(".class public final LOooO00o/OooO00o;", package_smali)
        self.assertIn("activity.reportFullyDrawn()", lambda_java)
        self.assertIn("Landroidx/activity/ComponentActivity;", lambda_smali)
        self.assertIn("->reportFullyDrawn()V", lambda_smali)

    def test_constraintlayout_sources_keep_the_obfuscated_internal_abi(self) -> None:
        constraint_set = (JAVA / "androidx/constraintlayout/widget/OooO0OO.java").read_text(encoding="utf-8")
        dependency_coordinates = (ROOT / "tools/recovered-dependencies.txt").read_text(encoding="utf-8")
        excludes = (ROOT / "tools/dependency-source-excludes.txt").read_text(encoding="utf-8")
        layout_source = (JAVA / "androidx/constraintlayout/widget/ConstraintLayout.java").read_text(encoding="utf-8")
        motion_source = (JAVA / "androidx/constraintlayout/motion/widget/MotionLayout.java").read_text(encoding="utf-8")

        self.assertIn("androidx.constraintlayout:constraintlayout-core:1.1.1", dependency_coordinates)
        self.assertNotIn("androidx.constraintlayout:constraintlayout:2.2.1", dependency_coordinates)
        self.assertIn("layoutParams.f3354OooO", constraint_set)
        self.assertIn("f3354OooO", layout_source)
        self.assertIn("layoutParams.OooO00o()", constraint_set)
        self.assertIn("public class ConstraintLayout", layout_source)
        self.assertIn("public class MotionLayout", motion_source)
        self.assertNotIn("**/androidx/constraintlayout/widget/ConstraintLayout.java", excludes)
        self.assertNotIn("**/androidx/constraintlayout/widget/Constraints.java", excludes)
        self.assertNotIn("**/androidx/constraintlayout/motion/widget/MotionLayout.java", excludes)

    def test_constraintattribute_enum_source_matches_smali_binary_name(self) -> None:
        enum_file = (JAVA / "androidx/constraintlayout/widget/ConstraintAttribute$AttributeType.java").read_text(encoding="utf-8")
        excludes = (ROOT / "tools/dependency-source-excludes.txt").read_text(encoding="utf-8")
        enum_smali = SMALI / "androidx/constraintlayout/widget/ConstraintAttribute$AttributeType.smali"
        original = smali_method(enum_smali, ".method static constructor <clinit>()V")
        enum_descriptor = re.search(r"\.class [^\n]* (L[^;]+;)", enum_smali.read_text(encoding="utf-8"))

        self.assertIsNotNone(enum_descriptor)
        self.assertEqual(enum_descriptor.group(1), "Landroidx/constraintlayout/widget/ConstraintAttribute$AttributeType;")
        self.assertIn("public enum ConstraintAttribute$AttributeType", enum_file)
        self.assertNotIn("**/androidx/constraintlayout/widget/ConstraintAttribute$AttributeType.java", excludes)
        java_enum = re.search(r"public enum ConstraintAttribute\$AttributeType\s*\{([^}]*)}", enum_file, re.DOTALL)
        self.assertIsNotNone(java_enum)
        enum_body = re.sub(r"/\*.*?\*/|//[^\n]*", "", java_enum.group(1), flags=re.DOTALL)
        java_constants = re.findall(r"\b([A-Z]+(?:_[A-Z]+)*)\b", enum_body)
        smali_constants = re.findall(r'const-string [vp]\d+, "([A-Z]+(?:_[A-Z]+)*)"', original)
        self.assertEqual(java_constants, smali_constants)
        license_text = (ROOT / "docs/licenses/CONSTRAINTLAYOUT-LICENSE.txt").read_text(encoding="utf-8")
        self.assertIn("Apache License", license_text)

    def test_package_identity_and_exact_biweekly_replacement_are_declared(self) -> None:
        gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
        manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
        self.assertIn('applicationId = "com.kaori.wakeupschedule"', gradle)
        self.assertIn('namespace = "com.kaori.wakeupschedule"', gradle)
        self.assertIn('implementation("net.sf.biweekly:biweekly:0.6.6")', gradle)
        excludes = (ROOT / "tools/dependency-source-excludes.txt").read_text(encoding="utf-8")
        self.assertIn("**/biweekly/", excludes)
        self.assertIn("dependencySourceExcludes.forEach { exclude(it) }", gradle)
        self.assertNotIn("package=\"com.suda.yzune.wakeupschedule\"", manifest)


    def test_media_session_callback_type_resolution_matches_smali_descriptors(self) -> None:
        java = (JAVA / "android/support/v4/media/session/MediaSessionCompat.java").read_text(encoding="utf-8")
        remote_info = (JAVA / "androidx/media/o00oO0o.java").read_text(encoding="utf-8")
        handler_smali = (SMALI / "android/support/v4/media/session/MediaSessionCompat$Callback$CallbackHandler.smali").read_text(encoding="utf-8")
        message_smali = (SMALI / "android/support/v4/media/session/MediaSessionCompat$MediaSessionImplBase$MessageHandler.smali").read_text(encoding="utf-8")
        api28_smali = (SMALI / "android/support/v4/media/session/MediaSessionCompat$MediaSessionImplApi28.smali").read_text(encoding="utf-8")

        self.assertIn("MediaSessionCompat.Callback.this.handleMediaPlayPauseKeySingleTapIfPending", java)
        self.assertIn("onMediaButtonEvent(KeyEvent keyEvent, MediaSessionCompat.Callback callback)", java)
        self.assertIn("MediaSessionCompat.Callback callback = MediaSessionImplBase.this.mCallback", java)
        self.assertIn("MediaSessionCompat$Callback;)V", message_smali)
        self.assertIn("MediaSessionCompat$Callback;->handleMediaPlayPauseKeySingleTapIfPending", handler_smali)
        self.assertIn("private o00oO0o()", remote_info)
        self.assertIn("invoke-direct {v1}, Ljava/lang/Object;-><init>()V", api28_smali)


    def test_csv_parser_constructor_matches_original_direct_super_invocation(self) -> None:
        java = (JAVA / "com/kaori/wakeupschedule/schedule_parser/parser/OooOo00.java").read_text(encoding="utf-8")
        base = (JAVA / "p110o00O00Oo/OooOO0O.java").read_text(encoding="utf-8")
        parser_smali = (SMALI / "com/suda/yzune/wakeupschedule/schedule_parser/parser/OooOo00.smali").read_text(encoding="utf-8")
        caller_smali = (SMALI / "com/suda/yzune/wakeupschedule/schedule_import/OooOOOO.smali").read_text(encoding="utf-8")

        self.assertIn("public OooOo00(String source) {", java)
        self.assertIn("super(source);", java)
        self.assertIn("public OooOO0O(String str)", base)
        self.assertIn(".super Lo00O00Oo/OooOO0O;", parser_smali)
        self.assertIn("invoke-direct {v2, p2}, Lo00O00Oo/OooOO0O;-><init>(Ljava/lang/String;)V", caller_smali)


    def test_honor_worker_recovered_iterators_use_the_existing_collections(self) -> None:
        java = (JAVA / "com/kaori/wakeupschedule/utils/HonorSuggestionWorker.java").read_text(encoding="utf-8")
        self.assertNotIn("r7.hasNext()", java)
        self.assertNotIn("r4.hasNext()", java)
        self.assertGreaterEqual(java.count("for (p088o000o00o.OooO0o oooO0o3 : arrayList3)"), 10)
        self.assertGreaterEqual(java.count("for (TimeDetailBean timeDetailBean : list2)"), 5)
        self.assertNotIn("OooO00o == coroutineSingletons)", java)
        self.assertEqual(java.count("(Object) o00O0O00.OooOO0O.f11387OooO00o == (Object) coroutineSingletons"), 6)
        smali = (SMALI / "com/suda/yzune/wakeupschedule/utils/HonorSuggestionWorker.smali").read_text(encoding="utf-8")
        self.assertIn("sget-object v0, Lo00O0O00/OooOO0O;->OooO00o:Lo00O0O00/OooOO0O;", smali)
        self.assertIn("if-ne v0, v1", smali)


    def test_course_dao_week_split_copies_match_smali_default_masks(self) -> None:
        java = (JAVA / "com/kaori/wakeupschedule/dao/OooO0O0.java").read_text(encoding="utf-8")
        smali = (SMALI / "com/suda/yzune/wakeupschedule/dao/OooO0O0.smali").read_text(encoding="utf-8")
        self.assertIn("import OooOo.OooO0o;", java)
        self.assertIn("new OooO0o(6)", java)
        self.assertIn("const/16 v16, 0x3f7f", smali)
        self.assertIn("const/16 v16, 0x3fbf", smali)
        self.assertIn("courseDetailBean.getEndWeek(),", java)
        self.assertIn("courseDetailBean.getType() == 0 ? i4 - 1 : i4 - 2,", java)
        self.assertIn("courseDetailBean.getType() == 0 ? i + 1 : i + 2,", java)
        self.assertNotIn("courseDetailBean.id", java)
        self.assertNotIn("courseDetailBean.startWeek", java)


    def test_schedule_activity_date_receiver_and_adapter_match_smali_abi(self) -> None:
        activity = (JAVA / "com/kaori/wakeupschedule/schedule/ScheduleActivity.java").read_text(encoding="utf-8")
        receiver = (JAVA / "com/kaori/wakeupschedule/schedule/ScheduleActivity$dateChangedReceiver$1.java").read_text(encoding="utf-8")
        adapter = (JAVA / "com/kaori/wakeupschedule/schedule/o00000OO.java").read_text(encoding="utf-8")
        receiver_smali = (SMALI / "com/suda/yzune/wakeupschedule/schedule/ScheduleActivity$dateChangedReceiver$1.smali").read_text(encoding="utf-8")
        resume_smali = (SMALI / "com/suda/yzune/wakeupschedule/schedule/ScheduleActivity$onResume$1.smali").read_text(encoding="utf-8")

        self.assertIn("new ScheduleActivity$dateChangedReceiver$1(this)", activity)
        self.assertIn("public final ScheduleActivity OooO00o", receiver)
        self.assertIn("->OooO00o:Lcom/suda/yzune/wakeupschedule/schedule/ScheduleActivity;", receiver_smali)
        self.assertIn("DateFormat.getDateInstance(DateFormat.SHORT)", receiver)
        self.assertIn("public o00000OO(int layoutId, java.util.List<?> data)", adapter)
        self.assertIn("invoke-direct {v4, v5, p1}, Lo0000OOO/OooO0o;-><init>(ILjava/util/List;)V", resume_smali)


    def test_schedule_activity_coroutine_and_window_reconstruction_matches_smali(self) -> None:
        activity = (JAVA / "com/kaori/wakeupschedule/schedule/ScheduleActivity.java").read_text(encoding="utf-8")
        modern = (JAVA / "p024Oooo0o/o0O00oO0.java").read_text(encoding="utf-8")
        legacy = (JAVA / "p024Oooo0o/o0O00o00.java").read_text(encoding="utf-8")
        modern_smali = (SMALI / "Oooo0o.1/o0O00oO0.smali").read_text(encoding="utf-8")
        legacy_smali = (SMALI / "Oooo0o.1/o0O00o00.smali").read_text(encoding="utf-8")
        activity_smali = (SMALI / "com/suda/yzune/wakeupschedule/schedule/ScheduleActivity.smali").read_text(encoding="utf-8")

        self.assertIn("ScheduleActivity.this.OooO0oO()", activity)
        self.assertIn("ScheduleActivity.this.OooO0Oo()", activity)
        self.assertIn("ScheduleActivity.this.OooO0o0()", activity)
        self.assertGreaterEqual(activity.count("kotlin.coroutines.OooO0o<?> oooO0o"), 2)
        self.assertIn("(Object) create(o00oo0o, oooO0o)", activity)
        self.assertIn("public o0O00oO0(android.view.Window window", modern)
        self.assertIn("public o0O00o00(android.view.Window window", legacy)
        self.assertIn(".super LOooo0o/o0O00o00;", modern_smali)
        self.assertIn(".super LOooo0o/o0oO0Ooo;", legacy_smali)
        self.assertIn("invoke-direct {v6, v1, v7}, LOooo0o/o0oO0Ooo;-><init>(Landroid/view/Window;Lcom/suda/yzune/wakeupschedule/dao/OooO00o;)V", activity_smali)


if __name__ == "__main__":
    unittest.main(verbosity=2)
