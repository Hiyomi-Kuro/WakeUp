package com.kaori.wakeupschedule.schedule;
import o00O0OOO.ScheduleAction;

import android.content.Intent;
import kotlin.jvm.internal.Lambda;

final class ScheduleActivity$startScheduleSettings$1 extends Lambda implements ScheduleAction {
    public static final ScheduleActivity$startScheduleSettings$1 INSTANCE = new ScheduleActivity$startScheduleSettings$1();

    public ScheduleActivity$startScheduleSettings$1() {
        super(1);
    }

    public final void invoke(Intent intent) {
        com.github.doyaaaaaken.kotlincsv.client.OooO.OooOOO0(intent, "$this$null");
    }

    @Override // ScheduleAction
    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((Intent) obj);
        return o00O0O00.OooOO0O.f11387OooO00o;
    }
}
